export interface Product {
  id: string;
  name: string;
  category: 'Living Room' | 'Bedroom' | 'Dining' | 'Home Office' | 'Storage' | 'Lighting' | 'Décor & Accents';
  subcategory: string;
  price: number;
  originalPrice?: number;
  rating: number;
  reviewCount: number;
  badge?: 'NEW' | 'BESTSELLER' | '15% OFF' | '20% OFF' | 'CRAFT EDITION' | 'SIGNATURE';
  image: string;
  gallery: string[];
  description: string;
  materials: string;
  dimensions: string;
  finishes: { name: string; hex: string }[];
  inStock: boolean;
  featured?: boolean;
  room?: 'Living' | 'Dining' | 'Bedroom' | 'Office';
}

export interface CartItem {
  product: Product;
  quantity: number;
  selectedFinish?: string;
}

export interface CategoryItem {
  id: string;
  name: string;
  slug: string;
  description: string;
  image: string;
  itemCount: number;
}

export interface Testimonial {
  id: string;
  quote: string;
  author: string;
  city: string;
  verified: boolean;
  rating: number;
  productPurchased: string;
  interiorImage: string;
}

export interface BrandValue {
  title: string;
  description: string;
  iconName: string;
}

export interface StoreStat {
  value: number;
  suffix: string;
  label: string;
  sublabel: string;
}

export type ActiveView = 'home' | 'shop' | 'living' | 'bedroom' | 'dining' | 'office' | 'decor' | 'sale' | 'journal' | 'about';
