import { Product, CategoryItem, Testimonial, BrandValue, StoreStat } from '../types';

export const CATEGORIES: CategoryItem[] = [
  {
    id: 'living',
    name: 'Living Room',
    slug: 'living',
    description: 'Sculptural seating, low credenzas, and modular linen sofas built for relaxed gathering.',
    image: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=700&q=80',
    itemCount: 42
  },
  {
    id: 'bedroom',
    name: 'Bedroom',
    slug: 'bedroom',
    description: 'Solid white oak beds, Belgian linen headboards, and soothing natural finishes.',
    image: 'https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=700&q=80',
    itemCount: 28
  },
  {
    id: 'dining',
    name: 'Dining',
    slug: 'dining',
    description: 'Architectural dining tables, cane-back chairs, and credenzas tailored for conversation.',
    image: 'https://images.unsplash.com/photo-1617806118233-18e1de247200?auto=format&fit=crop&w=700&q=80',
    itemCount: 34
  },
  {
    id: 'office',
    name: 'Home Office',
    slug: 'office',
    description: 'Minimalist walnut writing desks, ergonomic leather chairs, and considered organizers.',
    image: 'https://images.unsplash.com/photo-1524758631624-e2822e304c36?auto=format&fit=crop&w=700&q=80',
    itemCount: 19
  },
  {
    id: 'storage',
    name: 'Storage',
    slug: 'storage',
    description: 'Fluted sideboards, solid timber shelving, and seamless architectural wardrobes.',
    image: 'https://images.unsplash.com/photo-1595428774223-ef52624120d2?auto=format&fit=crop&w=700&q=80',
    itemCount: 26
  },
  {
    id: 'lighting',
    name: 'Lighting',
    slug: 'lighting',
    description: 'Ceramic table lamps, hand-blown glass fixtures, and warm alabaster chandeliers.',
    image: 'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=700&q=80',
    itemCount: 31
  },
  {
    id: 'decor',
    name: 'Décor & Accents',
    slug: 'decor',
    description: 'Artisan stoneware vases, textured wool bouclé throws, and hand-chiseled bowls.',
    image: 'https://images.unsplash.com/photo-1578749556568-bc2c40e68b61?auto=format&fit=crop&w=700&q=80',
    itemCount: 56
  }
];

export const PRODUCTS: Product[] = [
  {
    id: 'prod-arden-chair',
    name: 'Arden Lounge Chair',
    category: 'Living Room',
    subcategory: 'Armchairs',
    price: 1240,
    originalPrice: 1420,
    rating: 4.9,
    reviewCount: 48,
    badge: 'BESTSELLER',
    image: 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=1000&q=85',
    gallery: [
      'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=1000&q=85',
      'https://images.unsplash.com/photo-1567538096630-e0c55bd6374c?auto=format&fit=crop&w=1000&q=85',
      'https://images.unsplash.com/photo-1598300042247-d088f8ab3a91?auto=format&fit=crop&w=1000&q=85'
    ],
    description: 'Sculptural curved lines and deep ergonomic recline, hand-upholstered in Belgian textured linen over a kiln-dried European solid white oak frame. Designed to bring understated ease to reading corners and open living zones.',
    materials: 'FSC-Certified Solid European White Oak, 100% Belgian Washed Linen, High-Resilience Eco-Foam Core with Feather Down Layer',
    dimensions: '33.5"W x 34.0"D x 31.5"H (Seat Height: 17.5")',
    finishes: [
      { name: 'Oatmeal Linen & Natural Oak', hex: '#D9CDBD' },
      { name: 'Olive Velvet & Smoked Oak', hex: '#4E5B43' },
      { name: 'Charcoal Wool & Walnut', hex: '#24241F' }
    ],
    inStock: true,
    featured: true,
    room: 'Living'
  },
  {
    id: 'prod-rowan-table',
    name: 'Rowan Oak Dining Table',
    category: 'Dining',
    subcategory: 'Dining Tables',
    price: 2180,
    rating: 5.0,
    reviewCount: 32,
    badge: 'NEW',
    image: 'https://images.unsplash.com/photo-1615066390971-03e4e1c36ddf?auto=format&fit=crop&w=1000&q=85',
    gallery: [
      'https://images.unsplash.com/photo-1615066390971-03e4e1c36ddf?auto=format&fit=crop&w=1000&q=85',
      'https://images.unsplash.com/photo-1617806118233-18e1de247200?auto=format&fit=crop&w=1000&q=85'
    ],
    description: 'A monument to natural timber grain. The Rowan features a 2.5-inch solid bevel-edged top supported by gently tapered pillar legs with mortise-and-tenon architectural joinery. Seats eight comfortably.',
    materials: 'Solid American White Oak with hand-applied low-VOC matte wax oil seal.',
    dimensions: '88.0"L x 38.0"W x 29.5"H (Weight: 148 lbs)',
    finishes: [
      { name: 'Natural White Oak', hex: '#D7C2A5' },
      { name: 'Bleached Sand Oak', hex: '#ECE3D4' },
      { name: 'Warm Walnut Tone', hex: '#745943' }
    ],
    inStock: true,
    featured: true,
    room: 'Dining'
  },
  {
    id: 'prod-elara-sofa',
    name: 'Elara Linen Sofa',
    category: 'Living Room',
    subcategory: 'Sectionals & Sofas',
    price: 2850,
    originalPrice: 3200,
    rating: 4.8,
    reviewCount: 64,
    badge: '15% OFF',
    image: 'https://images.unsplash.com/photo-1493663284031-b7e3aefcae8e?auto=format&fit=crop&w=1000&q=85',
    gallery: [
      'https://images.unsplash.com/photo-1493663284031-b7e3aefcae8e?auto=format&fit=crop&w=1000&q=85',
      'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=1000&q=85'
    ],
    description: 'Generous proportions, feather-down wrap cushions, and removable loose slipcovers tailored from pure Belgian flax. Built to withstand relaxed family evenings while preserving an immaculate editorial silhouette.',
    materials: 'Belgian Washed Linen (Slipcovered & Washable), Sustainable Hardwood Frame, Goose Down Blend Cushions',
    dimensions: '94.0"W x 39.5"D x 31.0"H (Seat Depth: 25.5")',
    finishes: [
      { name: 'Warm Ivory Linen', hex: '#F7F4EE' },
      { name: 'Muted Forest Green', hex: '#26382C' },
      { name: 'Sand Bouclé', hex: '#D9CDBD' }
    ],
    inStock: true,
    featured: true,
    room: 'Living'
  },
  {
    id: 'prod-haven-sideboard',
    name: 'Haven Walnut Sideboard',
    category: 'Storage',
    subcategory: 'Credenzas',
    price: 1750,
    rating: 4.9,
    reviewCount: 29,
    badge: 'CRAFT EDITION',
    image: 'https://images.unsplash.com/photo-1595428774223-ef52624120d2?auto=format&fit=crop&w=1000&q=85',
    gallery: [
      'https://images.unsplash.com/photo-1595428774223-ef52624120d2?auto=format&fit=crop&w=1000&q=85',
      'https://images.unsplash.com/photo-1538688525198-9b88f6f53126?auto=format&fit=crop&w=1000&q=85'
    ],
    description: 'Subtle fluted tambour sliding panels glide silently to reveal adjustable interior shelving and discrete cable channels. Crafted in rich Appalachian black walnut with soft-closing Blum hardware.',
    materials: 'Solid American Black Walnut, Solid Brass Hardware Inset, Natural Plant-Based Satin Lacquer',
    dimensions: '72.0"W x 19.0"D x 30.5"H',
    finishes: [
      { name: 'Deep American Walnut', hex: '#745943' },
      { name: 'Natural Nordic Oak', hex: '#D7C2A5' }
    ],
    inStock: true,
    featured: true,
    room: 'Dining'
  },
  {
    id: 'prod-solis-lamp',
    name: 'Solis Ceramic Table Lamp',
    category: 'Lighting',
    subcategory: 'Table Lamps',
    price: 340,
    rating: 4.9,
    reviewCount: 53,
    badge: 'BESTSELLER',
    image: 'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=1000&q=85',
    gallery: [
      'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=1000&q=85',
      'https://images.unsplash.com/photo-1513506003901-1e6a229e2d15?auto=format&fit=crop&w=1000&q=85'
    ],
    description: 'Each ceramic base is thrown by hand on a potters wheel in Portugal, leaving delicate organic throw lines under a tactile chalk glaze. Paired with a custom natural linen drum shade with brass finial.',
    materials: 'Hand-thrown Terracotta with Matte Calcite Glaze, Natural Belgian Linen Shade, Twisted Cloth Cord',
    dimensions: '14.0"Dia x 22.5"H (Base Dia: 8.5")',
    finishes: [
      { name: 'Chalk White Matte', hex: '#EEE9DF' },
      { name: 'Olive Basalt', hex: '#4E5B43' },
      { name: 'Raw Terracotta', hex: '#B87857' }
    ],
    inStock: true,
    featured: true,
    room: 'Living'
  },
  {
    id: 'prod-mira-vase',
    name: 'Mira Artisan Stoneware Vase',
    category: 'Décor & Accents',
    subcategory: 'Vessels & Objects',
    price: 185,
    rating: 4.9,
    reviewCount: 38,
    badge: 'NEW',
    image: 'https://images.unsplash.com/photo-1578749556568-bc2c40e68b61?auto=format&fit=crop&w=1000&q=85',
    gallery: [
      'https://images.unsplash.com/photo-1578749556568-bc2c40e68b61?auto=format&fit=crop&w=1000&q=85',
      'https://images.unsplash.com/photo-1612196808214-b8e1d6145a8c?auto=format&fit=crop&w=1000&q=85'
    ],
    description: 'An architectural silhouette with dual asymmetrical handles, inspired by ancient Mediterranean amphorae. Water-tight interior with a textured exterior that invites touch.',
    materials: 'High-fire Stoneware with speckled sand texture and mineral oxide brush detail.',
    dimensions: '8.2"W x 7.5"D x 13.0"H',
    finishes: [
      { name: 'Warm Sandstone', hex: '#D9CDBD' },
      { name: 'Deep Sage Ash', hex: '#A7AD96' }
    ],
    inStock: true,
    featured: true,
    room: 'Living'
  },
  {
    id: 'prod-kanso-coffee-table',
    name: 'Kanso Low Profile Coffee Table',
    category: 'Living Room',
    subcategory: 'Coffee Tables',
    price: 890,
    originalPrice: 980,
    rating: 4.7,
    reviewCount: 22,
    image: 'https://images.unsplash.com/photo-1533090161767-e6ffed986c88?auto=format&fit=crop&w=1000&q=85',
    gallery: [
      'https://images.unsplash.com/photo-1533090161767-e6ffed986c88?auto=format&fit=crop&w=1000&q=85'
    ],
    description: 'Rooted in Japanese wabi-sabi philosophy, the Kanso table pairs clean orthogonal joinery with softened rounded corners. Low stance anchors open lounge spaces effortlessly.',
    materials: 'Solid White Oak with hand-rubbed organic oil wax finish.',
    dimensions: '48.0"L x 32.0"W x 13.5"H',
    finishes: [
      { name: 'Bleached Oak', hex: '#ECE3D4' },
      { name: 'Oiled Walnut', hex: '#745943' }
    ],
    inStock: true,
    room: 'Living'
  },
  {
    id: 'prod-astrid-bed',
    name: 'Astrid Upholstered Platform Bed',
    category: 'Bedroom',
    subcategory: 'Beds',
    price: 2400,
    rating: 5.0,
    reviewCount: 41,
    badge: 'SIGNATURE',
    image: 'https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=1000&q=85',
    gallery: [
      'https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=1000&q=85'
    ],
    description: 'An oasis of calm. Deep horizontal channels tufted in tactile organic wool-linen blend, framed by a low floating solid oak plinth that conceals supportive timber slats.',
    materials: 'Organic Flax Wool Blend, Kiln-Dried European Birch Core, Solid Oak Peripheral Base',
    dimensions: 'King: 84.0"W x 90.0"L x 44.0"H (Platform Height: 10.0")',
    finishes: [
      { name: 'Natural Ecru', hex: '#F7F4EE' },
      { name: 'Smoked Heather', hex: '#A99A87' },
      { name: 'Deep Olive', hex: '#26382C' }
    ],
    inStock: true,
    room: 'Bedroom'
  },
  {
    id: 'prod-sylvan-desk',
    name: 'Sylvan Architectural Writing Desk',
    category: 'Home Office',
    subcategory: 'Desks',
    price: 1620,
    rating: 4.8,
    reviewCount: 17,
    image: 'https://images.unsplash.com/photo-1518455027359-f3f8164ba6bd?auto=format&fit=crop&w=1000&q=85',
    gallery: [
      'https://images.unsplash.com/photo-1518455027359-f3f8164ba6bd?auto=format&fit=crop&w=1000&q=85'
    ],
    description: 'Precision proportions crafted for deep focus. Features a concealed leather-lined pencil drawer, hidden power management tray, and softly chamfered desktop edges.',
    materials: 'Solid White Oak or American Walnut, Full-grain Saddle Leather Inlay',
    dimensions: '60.0"W x 28.0"D x 29.5"H',
    finishes: [
      { name: 'Natural White Oak', hex: '#D7C2A5' },
      { name: 'American Walnut', hex: '#745943' }
    ],
    inStock: true,
    room: 'Office'
  },
  {
    id: 'prod-calder-pendant',
    name: 'Calder Brass & Alabaster Pendant',
    category: 'Lighting',
    subcategory: 'Ceiling Lighting',
    price: 520,
    rating: 4.9,
    reviewCount: 26,
    badge: 'NEW',
    image: 'https://images.unsplash.com/photo-1513506003901-1e6a229e2d15?auto=format&fit=crop&w=1000&q=85',
    gallery: [
      'https://images.unsplash.com/photo-1513506003901-1e6a229e2d15?auto=format&fit=crop&w=1000&q=85'
    ],
    description: 'Turned Spanish alabaster stone dome diffuses a warm, buttery glow, crowned with hand-finished unlacquered living brass that patinas gracefully with time.',
    materials: 'Genuine Spanish Alabaster, Solid Unlacquered Cast Brass',
    dimensions: '16.0"Dia x 9.5"H (Adjustable drop up to 72.0")',
    finishes: [
      { name: 'Living Aged Brass', hex: '#C49E68' },
      { name: 'Bronzed Patina', hex: '#4B3F38' }
    ],
    inStock: true,
    room: 'Dining'
  },
  {
    id: 'prod-travertine-plinth',
    name: 'Tove Fluted Travertine Plinth',
    category: 'Décor & Accents',
    subcategory: 'Pedestals & Accent Tables',
    price: 640,
    rating: 4.9,
    reviewCount: 15,
    image: 'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=1000&q=85',
    gallery: [
      'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=1000&q=85'
    ],
    description: 'Honed Italian Roman travertine carved with subtle vertical flute relief. Can serve as an architectural display plinth for ceramics or a statement side table.',
    materials: 'Solid Natural Roman Travertine Stone (Honed Unfilled finish)',
    dimensions: '13.5"W x 13.5"D x 20.0"H (Weight: 68 lbs)',
    finishes: [
      { name: 'Warm Cream Travertine', hex: '#EEE9DF' },
      { name: 'Piedra Grey Limestone', hex: '#A99A87' }
    ],
    inStock: true,
    room: 'Living'
  },
  {
    id: 'prod-aurelia-rug',
    name: 'Aurelia Hand-Knotted Wool Rug',
    category: 'Décor & Accents',
    subcategory: 'Rugs',
    price: 1150,
    rating: 4.8,
    reviewCount: 31,
    image: 'https://images.unsplash.com/photo-1600121848594-d8644e57abab?auto=format&fit=crop&w=1000&q=85',
    gallery: [
      'https://images.unsplash.com/photo-1600121848594-d8644e57abab?auto=format&fit=crop&w=1000&q=85'
    ],
    description: 'Woven entirely by hand by master artisans over three months using un-dyed New Zealand wool. Features an ultra-soft high/low pile micro-geometric lattice.',
    materials: '100% Hand-spun New Zealand Wool with Organic Cotton Warp',
    dimensions: '8\' x 10\' (Also available in 9\' x 12\')',
    finishes: [
      { name: 'Un-dyed Natural Ivory', hex: '#F7F4EE' },
      { name: 'Soft Sage Muted', hex: '#A7AD96' }
    ],
    inStock: true,
    room: 'Living'
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 't-1',
    quote: 'The craftsmanship is exceptional and the entire ordering experience felt effortless. The Arden chair and Elara sofa have completely transformed our sunroom into a haven of quiet comfort.',
    author: 'Elena R.',
    city: 'Cotswolds & London',
    verified: true,
    rating: 5,
    productPurchased: 'Arden Lounge Chair & Elara Linen Sofa',
    interiorImage: 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=800&q=85'
  },
  {
    id: 't-2',
    quote: 'From the white-glove delivery team who assembled our dining table with immense care, to the tactile quality of the white oak grain, Vale & Oak is what real luxury furniture should feel like.',
    author: 'Marcus & Julian T.',
    city: 'Copenhagen',
    verified: true,
    rating: 5,
    productPurchased: 'Rowan Oak Dining Table (8-Seater)',
    interiorImage: 'https://images.unsplash.com/photo-1617806118233-18e1de247200?auto=format&fit=crop&w=800&q=85'
  },
  {
    id: 't-3',
    quote: 'As an interior architect, I am meticulous about wood joinery and natural dye tones. Vale & Oak delivers heirloom-grade construction at prices that feel refreshingly honest.',
    author: 'Sophia V.',
    city: 'Zurich & Milan',
    verified: true,
    rating: 5,
    productPurchased: 'Haven Walnut Sideboard & Tove Plinth',
    interiorImage: 'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=800&q=85'
  },
  {
    id: 't-4',
    quote: 'The Solis ceramic lamp casts the warmest, softest evening glow. Everyone who walks into our apartment asks where we found it. We will be furnishing our second home exclusively with them.',
    author: 'David H.',
    city: 'San Francisco',
    verified: true,
    rating: 5,
    productPurchased: 'Solis Ceramic Lamp & Mira Vase',
    interiorImage: 'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=800&q=85'
  }
];

export const BRAND_VALUES: BrandValue[] = [
  {
    title: 'Timeless Design',
    description: 'Proportions sculpted to transcend seasonal fads and mature with quiet dignity in your living spaces.',
    iconName: 'Compass'
  },
  {
    title: 'Premium Materials',
    description: 'FSC-certified timber, un-dyed pure Belgian flax, and artisan Portuguese stoneware sourced with care.',
    iconName: 'ShieldCheck'
  },
  {
    title: 'Considered Craftsmanship',
    description: 'Honoring time-tested joinery techniques married with modern ergonomic engineering for true longevity.',
    iconName: 'Sparkles'
  },
  {
    title: 'Responsible Choices',
    description: '100% plastic-free packaging, low-VOC finishes, and fair-wage independent family workshop partnerships.',
    iconName: 'Leaf'
  }
];

export const STORE_STATS: StoreStat[] = [
  {
    value: 25,
    suffix: 'K+',
    label: 'Happy Homes',
    sublabel: 'Furnished across 24 countries'
  },
  {
    value: 10,
    suffix: 'K+',
    label: 'Pieces Delivered',
    sublabel: 'With complimentary white glove care'
  },
  {
    value: 98,
    suffix: '%',
    label: 'Positive Reviews',
    sublabel: 'From verified homeowners & designers'
  },
  {
    value: 4.8,
    suffix: '/5',
    label: 'Average Rating',
    sublabel: 'Over 14,000 independent ratings'
  }
];

export const ROOM_STORIES = [
  {
    id: 'living-sanctuary',
    title: 'The Sunlit Living Sanctuary',
    room: 'Living Room',
    image: 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1200&q=85',
    quote: 'Natural light washing across raw lime-wash walls, softened by tactile Belgian linen and warm European oak.',
    featuredProductIds: ['prod-arden-chair', 'prod-elara-sofa', 'prod-kanso-coffee-table', 'prod-mira-vase']
  },
  {
    id: 'dining-gathering',
    title: 'The Evening Dining Vignette',
    room: 'Dining Room',
    image: 'https://images.unsplash.com/photo-1617806118233-18e1de247200?auto=format&fit=crop&w=1200&q=85',
    quote: 'Solid timber, warm overhead alabaster glow, and chairs sculpted for conversations that stretch late into the night.',
    featuredProductIds: ['prod-rowan-table', 'prod-haven-sideboard', 'prod-calder-pendant']
  }
];
