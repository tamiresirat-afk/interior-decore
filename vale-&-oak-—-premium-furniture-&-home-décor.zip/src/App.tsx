/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { ActiveView, Product, CartItem } from './types';
import { PRODUCTS } from './data/products';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { TrustPanel } from './components/TrustPanel';
import { CategorySection } from './components/CategorySection';
import { ProductGrid } from './components/ProductGrid';
import { CampaignBanner } from './components/CampaignBanner';
import { StoreStatistics } from './components/StoreStatistics';
import { Testimonials } from './components/Testimonials';
import { Newsletter } from './components/Newsletter';
import { Footer } from './components/Footer';
import { CartDrawer } from './components/CartDrawer';
import { WishlistDrawer } from './components/WishlistDrawer';
import { SearchModal } from './components/SearchModal';
import { QuickViewModal } from './components/QuickViewModal';
import { RoomsModal } from './components/RoomsModal';
import { AccountModal } from './components/AccountModal';
import { CheckoutModal } from './components/CheckoutModal';
import { ShopView } from './components/ShopView';
import { JournalView } from './components/JournalView';
import { AboutView } from './components/AboutView';
import { ToastContainer, ToastMessage } from './components/Toast';

export default function App() {
  const [activeView, setActiveView] = useState<ActiveView>('home');
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<string>('All');
  
  // Cart state with localStorage persistence
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('vale_oak_cart');
      if (saved) return JSON.parse(saved);
    } catch {
      // Ignore
    }
    // Default initial demonstration item
    const initialProduct = PRODUCTS[0]; // Arden Lounge Chair
    return [{ product: initialProduct, quantity: 1, selectedFinish: 'Oatmeal Linen & Natural Oak' }];
  });

  // Wishlist state with localStorage persistence
  const [wishlistIds, setWishlistIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('vale_oak_wishlist');
      if (saved) return JSON.parse(saved);
    } catch {
      // Ignore
    }
    return ['prod-haven-sideboard', 'prod-solis-lamp'];
  });

  // Modal / Drawer visibility states
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isWishlistOpen, setIsWishlistOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isAccountOpen, setIsAccountOpen] = useState(false);
  const [isRoomsOpen, setIsRoomsOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);

  // Toast notifications
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Sync cart to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('vale_oak_cart', JSON.stringify(cart));
    } catch {
      // Ignore
    }
  }, [cart]);

  // Sync wishlist to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('vale_oak_wishlist', JSON.stringify(wishlistIds));
    } catch {
      // Ignore
    }
  }, [wishlistIds]);

  const showToast = (type: 'cart' | 'wishlist' | 'info', title: string, subtitle?: string) => {
    const id = Date.now().toString();
    const newToast: ToastMessage = { id, type, title, subtitle };
    setToasts((prev) => [...prev, newToast]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3800);
  };

  const handleDismissToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Cart operations
  const handleAddToCart = (product: Product, quantity = 1, finish?: string) => {
    const chosenFinish = finish || (product.finishes?.[0]?.name);
    setCart((prev) => {
      const existingIdx = prev.findIndex(
        (item) => item.product.id === product.id && item.selectedFinish === chosenFinish
      );
      if (existingIdx > -1) {
        const next = [...prev];
        next[existingIdx].quantity += quantity;
        return next;
      } else {
        return [...prev, { product, quantity, selectedFinish: chosenFinish }];
      }
    });

    showToast('cart', `Added ${product.name}`, `${quantity} item(s) in bag • $${(product.price * quantity).toLocaleString()}`);
  };

  const handleUpdateQuantity = (productId: string, quantity: number) => {
    setCart((prev) =>
      prev.map((item) => (item.product.id === productId ? { ...item, quantity } : item))
    );
  };

  const handleRemoveFromCart = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const handleOrderCompleted = () => {
    setCart([]);
    showToast('info', 'Order Confirmed', 'A confirmation summary was generated.');
  };

  // Wishlist operations
  const handleToggleWishlist = (product: Product) => {
    setWishlistIds((prev) => {
      const exists = prev.includes(product.id);
      if (exists) {
        showToast('info', 'Removed from Wishlist', product.name);
        return prev.filter((id) => id !== product.id);
      } else {
        showToast('wishlist', 'Saved to Wishlist', product.name);
        return [...prev, product.id];
      }
    });
  };

  const handleSelectCategory = (categoryName: string) => {
    setSelectedCategoryFilter(categoryName);
    setActiveView('shop');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const wishlistProducts = PRODUCTS.filter((p) => wishlistIds.includes(p.id));
  const cartItemCount = cart.reduce((acc, item) => acc + item.quantity, 0);

  return (
    <div className="min-h-screen flex flex-col bg-[#F7F4EE] text-[#24241F] font-sans-ui selection:bg-[#4E5B43] selection:text-white">
      {/* Top Banner, Utility Bar, Main Header */}
      <Header
        activeView={activeView}
        setActiveView={setActiveView}
        cartCount={cartItemCount}
        wishlistCount={wishlistIds.length}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenWishlist={() => setIsWishlistOpen(true)}
        onOpenSearch={() => setIsSearchOpen(true)}
        onOpenAccount={() => setIsAccountOpen(true)}
        onSelectCategory={handleSelectCategory}
      />

      {/* Main Dynamic View Content */}
      <main className="flex-1">
        {activeView === 'home' && (
          <>
            {/* 4. Hero Section */}
            <Hero
              onShopClick={() => {
                setActiveView('shop');
                setSelectedCategoryFilter('All');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              onExploreRoomsClick={() => setIsRoomsOpen(true)}
            />

            {/* 5. Floating Trust & Benefits Panel */}
            <TrustPanel />

            {/* 6. Shop by Category */}
            <CategorySection onSelectCategory={handleSelectCategory} />

            {/* 7. Featured Products Grid */}
            <ProductGrid
              products={PRODUCTS}
              wishlistIds={wishlistIds}
              onToggleWishlist={handleToggleWishlist}
              onAddToCart={(p) => handleAddToCart(p, 1)}
              onQuickView={(p) => setQuickViewProduct(p)}
              onViewAllClick={() => {
                setActiveView('shop');
                setSelectedCategoryFilter('All');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
            />

            {/* 8. Large Promotional / Collection Campaign Banner */}
            <CampaignBanner
              onShopEditClick={() => {
                setActiveView('shop');
                setSelectedCategoryFilter('All');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
            />

            {/* 9. Social Proof & Store Statistics */}
            <StoreStatistics />

            {/* 10. Testimonial Section */}
            <Testimonials />

            {/* 11. Newsletter / Community Section */}
            <Newsletter />
          </>
        )}

        {activeView === 'shop' && (
          <>
            <ShopView
              products={PRODUCTS}
              initialCategory={selectedCategoryFilter}
              wishlistIds={wishlistIds}
              onToggleWishlist={handleToggleWishlist}
              onAddToCart={(p) => handleAddToCart(p, 1)}
              onQuickView={(p) => setQuickViewProduct(p)}
              onBackToHome={() => {
                setActiveView('home');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
            />
            <Newsletter />
          </>
        )}

        {activeView === 'journal' && (
          <>
            <JournalView
              onBackToHome={() => {
                setActiveView('home');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              onShopClick={() => {
                setActiveView('shop');
                setSelectedCategoryFilter('All');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
            />
            <Newsletter />
          </>
        )}

        {activeView === 'about' && (
          <>
            <AboutView
              onBackToHome={() => {
                setActiveView('home');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              onShopClick={() => {
                setActiveView('shop');
                setSelectedCategoryFilter('All');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
            />
            <Newsletter />
          </>
        )}
      </main>

      {/* 12. Footer */}
      <Footer
        onNavigate={(view, cat) => {
          setActiveView(view);
          if (cat) setSelectedCategoryFilter(cat);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onOpenContactModal={() => setIsAccountOpen(true)}
      />

      {/* Interactive Global Drawers & Modals */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cart}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveFromCart}
        onOpenCheckout={() => {
          setIsCartOpen(false);
          setIsCheckoutOpen(true);
        }}
        onShopClick={() => {
          setActiveView('shop');
          setSelectedCategoryFilter('All');
        }}
      />

      <WishlistDrawer
        isOpen={isWishlistOpen}
        onClose={() => setIsWishlistOpen(false)}
        wishlistProducts={wishlistProducts}
        onRemoveFromWishlist={handleToggleWishlist}
        onAddToCart={(p) => handleAddToCart(p, 1)}
        onQuickView={(p) => setQuickViewProduct(p)}
        onShopClick={() => {
          setActiveView('shop');
          setSelectedCategoryFilter('All');
        }}
      />

      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        products={PRODUCTS}
        onSelectProduct={(p) => setQuickViewProduct(p)}
      />

      <QuickViewModal
        product={quickViewProduct}
        isOpen={!!quickViewProduct}
        onClose={() => setQuickViewProduct(null)}
        isWishlisted={quickViewProduct ? wishlistIds.includes(quickViewProduct.id) : false}
        onToggleWishlist={handleToggleWishlist}
        onAddToCart={handleAddToCart}
      />

      <RoomsModal
        isOpen={isRoomsOpen}
        onClose={() => setIsRoomsOpen(false)}
        onQuickView={(p) => setQuickViewProduct(p)}
        onShopClick={() => {
          setActiveView('shop');
          setSelectedCategoryFilter('All');
        }}
      />

      <AccountModal
        isOpen={isAccountOpen}
        onClose={() => setIsAccountOpen(false)}
        wishlistCount={wishlistIds.length}
        onOpenWishlist={() => {
          setIsAccountOpen(false);
          setIsWishlistOpen(true);
        }}
      />

      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        items={cart}
        onOrderCompleted={handleOrderCompleted}
      />

      <ToastContainer
        toasts={toasts}
        onDismiss={handleDismissToast}
        onOpenCart={() => setIsCartOpen(true)}
      />
    </div>
  );
}
