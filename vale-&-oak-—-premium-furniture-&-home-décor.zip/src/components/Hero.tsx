import React from 'react';
import { ArrowRight, Compass } from 'lucide-react';
import { ActiveView } from '../types';

interface HeroProps {
  onShopClick: () => void;
  onExploreRoomsClick: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onShopClick, onExploreRoomsClick }) => {
  return (
    <section 
      id="hero-section" 
      className="relative w-full bg-[#F7F4EE] overflow-hidden"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-8 pt-4 sm:pt-6 pb-20 sm:pb-28">
        <div className="relative rounded-2xl sm:rounded-3xl overflow-hidden min-h-[520px] sm:min-h-[580px] lg:min-h-[620px] flex items-center shadow-lg border border-[#E5E0D8]/80">
          {/* Background Editorial Interior Photography */}
          <div className="absolute inset-0 z-0">
            <img
              src="https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=2000&q=88"
              alt="Bright contemporary sunlit living room with arched windows, warm plaster walls, olive green accents, sculptural wood furniture, and linen cushions"
              className="w-full h-full object-cover object-center transform scale-100 transition-transform duration-1000 ease-out hover:scale-102"
              loading="eager"
            />
            {/* Editorial subtle gradient overlay for pristine typography contrast without muddying the daylight */}
            <div className="absolute inset-0 bg-gradient-to-r from-[#F7F4EE]/95 via-[#F7F4EE]/80 to-transparent sm:w-3/4 lg:w-3/5" />
            <div className="absolute inset-0 bg-black/10 sm:hidden" />
          </div>

          {/* Hero Content Box */}
          <div className="relative z-10 p-6 sm:p-12 lg:p-16 max-w-xl lg:max-w-2xl text-left">
            {/* Eyebrow */}
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/80 border border-[#E5E0D8] mb-4 sm:mb-6 shadow-2xs backdrop-blur-xs">
              <span className="w-1.5 h-1.5 rounded-full bg-[#4E5B43]" />
              <span className="text-[11px] sm:text-xs font-semibold tracking-[0.2em] text-[#4E5B43] uppercase">
                DESIGNED FOR EVERYDAY LIVING
              </span>
            </div>

            {/* Editorial Heading */}
            <h1 className="font-serif-display text-4xl sm:text-5xl lg:text-[64px] font-normal leading-[1.08] text-[#24241F] tracking-tight mb-4 sm:mb-6">
              Beautiful Spaces. <br />
              <span className="italic font-light text-[#26382C]">Effortless Comfort.</span>
            </h1>

            {/* Supporting Copy */}
            <p className="text-[#6E6C65] text-base sm:text-lg leading-relaxed mb-8 max-w-lg font-normal">
              Thoughtfully selected furniture and décor crafted to bring warmth, character, and lasting comfort to every room. Handcrafted with solid FSC-timber and pure organic linen.
            </p>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3.5 sm:gap-4">
              {/* Primary Dark Forest Button */}
              <button
                id="hero-primary-cta"
                onClick={onShopClick}
                className="group inline-flex items-center justify-center gap-2.5 bg-[#26382C] hover:bg-[#19271E] text-[#F7F4EE] px-7 py-3.5 rounded-lg text-[13px] font-medium tracking-wider transition-all duration-200 transform hover:-translate-y-0.5 active:translate-y-0 shadow-md hover:shadow-lg"
              >
                <span>SHOP COLLECTION</span>
                <ArrowRight className="w-4 h-4 transition-transform duration-200 group-hover:translate-x-1" />
              </button>

              {/* Secondary Outlined Button */}
              <button
                id="hero-secondary-cta"
                onClick={onExploreRoomsClick}
                className="inline-flex items-center justify-center gap-2 bg-white/90 hover:bg-white text-[#24241F] hover:text-[#26382C] border border-[#E5E0D8] hover:border-[#A99A87] px-6 py-3.5 rounded-lg text-[13px] font-medium tracking-wider transition-all duration-200 shadow-2xs hover:shadow-xs"
              >
                <Compass className="w-4 h-4 text-[#4E5B43]" />
                <span>EXPLORE ROOMS</span>
              </button>
            </div>

            {/* Small subtle assurance */}
            <div className="mt-8 pt-6 border-t border-[#E5E0D8]/60 flex items-center gap-6 text-[12px] text-[#6E6C65]">
              <div className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-[#4E5B43]" />
                <span>Solid Timber & Organic Flax</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-[#4E5B43]" />
                <span>White-Glove Placement Included</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
