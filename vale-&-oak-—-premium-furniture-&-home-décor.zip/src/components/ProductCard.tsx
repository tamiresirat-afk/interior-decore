import React from 'react';
import { Heart, Star, ShoppingBag, Eye } from 'lucide-react';
import { Product } from '../types';

interface ProductCardProps {
  product: Product;
  isWishlisted: boolean;
  onToggleWishlist: (product: Product) => void;
  onAddToCart: (product: Product) => void;
  onQuickView: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  isWishlisted,
  onToggleWishlist,
  onAddToCart,
  onQuickView
}) => {
  return (
    <div className="group relative bg-white rounded-xl border border-[#E5E0D8] overflow-hidden flex flex-col transition-all duration-300 hover:-translate-y-1 hover:shadow-md hover:border-[#D1C9BD]">
      {/* Product Image Area */}
      <div className="relative aspect-square w-full bg-[#F7F4EE] overflow-hidden">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover object-center transform transition-transform duration-500 ease-out group-hover:scale-105"
          loading="lazy"
        />

        {/* Badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-1.5 z-10">
          {product.badge && (
            <span className={`text-[10px] uppercase tracking-wider font-semibold px-2 py-0.5 rounded-sm shadow-2xs ${
              product.badge === 'BESTSELLER' 
                ? 'bg-[#26382C] text-[#F7F4EE]'
                : product.badge === 'NEW'
                ? 'bg-[#4E5B43] text-white'
                : product.badge === '15% OFF' || product.badge === '20% OFF'
                ? 'bg-[#745943] text-white'
                : 'bg-[#A99A87] text-white'
            }`}>
              {product.badge}
            </span>
          )}
        </div>

        {/* Wishlist Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            onToggleWishlist(product);
          }}
          className={`absolute top-3 right-3 w-8 h-8 rounded-full flex items-center justify-center transition-all duration-200 shadow-xs z-10 ${
            isWishlisted 
              ? 'bg-[#4E5B43] text-white' 
              : 'bg-white/90 text-[#6E6C65] hover:text-[#26382C] hover:bg-white'
          }`}
          aria-label={isWishlisted ? "Remove from wishlist" : "Add to wishlist"}
        >
          <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-current' : ''}`} />
        </button>

        {/* Quick View Floating Pill Button on Hover */}
        <div className="absolute inset-x-3 bottom-3 opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex gap-2 z-10">
          <button
            onClick={() => onQuickView(product)}
            className="flex-1 py-2 bg-white/95 hover:bg-white text-[#24241F] text-[11px] font-semibold tracking-wider uppercase rounded-md shadow-sm border border-[#E5E0D8] flex items-center justify-center gap-1.5 transition-colors"
          >
            <Eye className="w-3.5 h-3.5 text-[#4E5B43]" />
            <span>Quick View</span>
          </button>
        </div>
      </div>

      {/* Product Details */}
      <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between text-left">
        <div>
          {/* Subcategory & Star Rating */}
          <div className="flex items-center justify-between gap-2 mb-1.5 text-[11px] text-[#A99A87]">
            <span className="uppercase tracking-wider">{product.subcategory}</span>
            <div className="flex items-center gap-1 text-[#24241F]">
              <Star className="w-3.5 h-3.5 fill-[#C49E68] text-[#C49E68]" />
              <span className="font-semibold text-xs">{product.rating}</span>
              <span className="text-[#6E6C65]">({product.reviewCount})</span>
            </div>
          </div>

          {/* Product Name */}
          <h3 
            onClick={() => onQuickView(product)}
            className="font-serif-display text-[17px] sm:text-[18px] font-medium text-[#24241F] group-hover:text-[#26382C] transition-colors leading-snug cursor-pointer mb-2"
          >
            {product.name}
          </h3>

          {/* Finish Swatches Preview */}
          {product.finishes && product.finishes.length > 0 && (
            <div className="flex items-center gap-1.5 mb-3">
              {product.finishes.map((f, i) => (
                <span 
                  key={i} 
                  title={f.name}
                  className="w-3 h-3 rounded-full border border-black/15 shadow-2xs"
                  style={{ backgroundColor: f.hex }}
                />
              ))}
              <span className="text-[10px] text-[#A99A87] ml-1">
                {product.finishes.length} finishes
              </span>
            </div>
          )}
        </div>

        {/* Pricing & Quick Add Action */}
        <div className="pt-2 border-t border-[#E5E0D8]/60 flex items-center justify-between gap-2 mt-2">
          <div className="flex items-baseline gap-2">
            <span className="text-sm sm:text-base font-semibold text-[#24241F]">
              ${product.price.toLocaleString()}
            </span>
            {product.originalPrice && (
              <span className="text-xs text-[#A99A87] line-through font-normal">
                ${product.originalPrice.toLocaleString()}
              </span>
            )}
          </div>

          <button
            onClick={() => onAddToCart(product)}
            className="p-2 sm:px-3 sm:py-1.5 bg-[#F7F4EE] hover:bg-[#26382C] text-[#26382C] hover:text-[#F7F4EE] rounded-md text-xs font-medium tracking-wide transition-all duration-200 flex items-center gap-1.5 border border-[#E5E0D8] hover:border-[#26382C]"
            aria-label={`Add ${product.name} to cart`}
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Add</span>
          </button>
        </div>
      </div>
    </div>
  );
};
