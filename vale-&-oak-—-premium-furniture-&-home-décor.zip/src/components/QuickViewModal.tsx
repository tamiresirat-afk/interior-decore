import React, { useState } from 'react';
import { X, Star, Heart, ShoppingBag, Truck, ShieldCheck, Check, RotateCcw } from 'lucide-react';
import { Product } from '../types';

interface QuickViewModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
  isWishlisted: boolean;
  onToggleWishlist: (product: Product) => void;
  onAddToCart: (product: Product, quantity: number, finish?: string) => void;
}

export const QuickViewModal: React.FC<QuickViewModalProps> = ({
  product,
  isOpen,
  onClose,
  isWishlisted,
  onToggleWishlist,
  onAddToCart
}) => {
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const [selectedFinish, setSelectedFinish] = useState<string>('');
  const [quantity, setQuantity] = useState(1);
  const [addedAnimation, setAddedAnimation] = useState(false);

  // Sync active finish when product changes
  React.useEffect(() => {
    if (product && product.finishes && product.finishes.length > 0) {
      setSelectedFinish(product.finishes[0].name);
      setSelectedImageIndex(0);
      setQuantity(1);
      setAddedAnimation(false);
    }
  }, [product]);

  if (!isOpen || !product) return null;

  const handleAdd = () => {
    onAddToCart(product, quantity, selectedFinish);
    setAddedAnimation(true);
    setTimeout(() => setAddedAnimation(false), 1800);
  };

  const images = product.gallery && product.gallery.length > 0 ? product.gallery : [product.image];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      {/* Modal Card */}
      <div className="relative w-full max-w-4xl bg-white rounded-2xl sm:rounded-3xl shadow-2xl border border-[#E5E0D8] overflow-hidden z-10 animate-in fade-in zoom-in-95 duration-200 my-auto">
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 w-9 h-9 rounded-full bg-white/90 hover:bg-white text-[#24241F] flex items-center justify-center shadow-md border border-[#E5E0D8] transition-all"
          aria-label="Close product view"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2">
          {/* Left Column: Image Gallery */}
          <div className="bg-[#F7F4EE] p-6 flex flex-col justify-between border-b md:border-b-0 md:border-r border-[#E5E0D8]">
            {/* Main Stage Image */}
            <div className="relative aspect-square w-full rounded-xl overflow-hidden bg-white shadow-2xs">
              <img
                src={images[selectedImageIndex] || product.image}
                alt={product.name}
                className="w-full h-full object-cover object-center transition-all duration-300"
              />
              {product.badge && (
                <span className="absolute top-3 left-3 text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-sm bg-[#26382C] text-[#F7F4EE] shadow-xs">
                  {product.badge}
                </span>
              )}
            </div>

            {/* Thumbnails */}
            {images.length > 1 && (
              <div className="flex gap-2.5 mt-4 overflow-x-auto pb-1">
                {images.map((img, i) => (
                  <button
                    key={i}
                    onClick={() => setSelectedImageIndex(i)}
                    className={`w-16 h-16 rounded-lg overflow-hidden border-2 transition-all flex-shrink-0 ${
                      selectedImageIndex === i 
                        ? 'border-[#26382C] shadow-xs' 
                        : 'border-[#E5E0D8] opacity-70 hover:opacity-100'
                    }`}
                  >
                    <img src={img} alt="" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Right Column: Product Narrative & Controls */}
          <div className="p-6 sm:p-8 flex flex-col justify-between text-left max-h-[80vh] overflow-y-auto">
            <div>
              {/* Category & Ratings */}
              <div className="flex items-center justify-between gap-2 text-xs text-[#6E6C65] mb-2">
                <span className="uppercase tracking-widest text-[11px] font-semibold text-[#4E5B43]">
                  {product.category} — {product.subcategory}
                </span>
                <div className="flex items-center gap-1">
                  <Star className="w-4 h-4 fill-[#C49E68] text-[#C49E68]" />
                  <span className="font-semibold text-[#24241F]">{product.rating}</span>
                  <span>({product.reviewCount} reviews)</span>
                </div>
              </div>

              {/* Title */}
              <h2 className="font-serif-display text-2xl sm:text-3xl text-[#24241F] font-medium leading-snug mb-3">
                {product.name}
              </h2>

              {/* Price */}
              <div className="flex items-baseline gap-3 mb-4">
                <span className="text-xl sm:text-2xl font-semibold text-[#24241F]">
                  ${product.price.toLocaleString()}
                </span>
                {product.originalPrice && (
                  <span className="text-sm text-[#A99A87] line-through font-normal">
                    ${product.originalPrice.toLocaleString()}
                  </span>
                )}
                <span className="text-xs font-semibold text-[#4E5B43] bg-[#F7F4EE] px-2 py-0.5 rounded-full border border-[#E5E0D8]">
                  In Stock & Ready to Ship
                </span>
              </div>

              {/* Description */}
              <p className="text-xs sm:text-sm text-[#6E6C65] leading-relaxed mb-6 font-normal">
                {product.description}
              </p>

              {/* Finish Options */}
              {product.finishes && product.finishes.length > 0 && (
                <div className="mb-6">
                  <label className="block text-xs font-semibold text-[#24241F] uppercase tracking-wider mb-2">
                    Finishing: <span className="font-normal text-[#6E6C65] normal-case">{selectedFinish}</span>
                  </label>
                  <div className="flex items-center gap-2.5">
                    {product.finishes.map((finish, idx) => (
                      <button
                        key={idx}
                        onClick={() => setSelectedFinish(finish.name)}
                        className={`group relative p-1 rounded-full border-2 transition-all ${
                          selectedFinish === finish.name 
                            ? 'border-[#26382C] scale-105' 
                            : 'border-transparent hover:border-[#D9CDBD]'
                        }`}
                        title={finish.name}
                      >
                        <span 
                          className="block w-6 h-6 rounded-full border border-black/15 shadow-2xs"
                          style={{ backgroundColor: finish.hex }}
                        />
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Materials & Dimensions Details */}
              <div className="space-y-2 py-3 border-y border-[#E5E0D8] text-xs text-[#6E6C65] mb-6">
                <div>
                  <strong className="text-[#24241F] font-medium">Materials: </strong>
                  <span>{product.materials}</span>
                </div>
                <div>
                  <strong className="text-[#24241F] font-medium">Dimensions: </strong>
                  <span>{product.dimensions}</span>
                </div>
              </div>
            </div>

            {/* Actions: Quantity + Add to Cart + Wishlist */}
            <div className="space-y-3 pt-2">
              <div className="flex items-center gap-3">
                {/* Quantity */}
                <div className="flex items-center border border-[#E5E0D8] rounded-lg bg-[#F7F4EE] px-2 py-2">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="px-2 text-sm text-[#6E6C65] hover:text-[#24241F]"
                  >
                    -
                  </button>
                  <span className="px-3 text-xs font-semibold text-[#24241F]">{quantity}</span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="px-2 text-sm text-[#6E6C65] hover:text-[#24241F]"
                  >
                    +
                  </button>
                </div>

                {/* Primary Add to Bag Button */}
                <button
                  onClick={handleAdd}
                  className="flex-1 bg-[#26382C] hover:bg-[#19271E] text-[#F7F4EE] py-3.5 rounded-lg text-xs font-semibold tracking-wider uppercase transition-all duration-200 flex items-center justify-center gap-2 shadow-md"
                >
                  {addedAnimation ? (
                    <>
                      <Check className="w-4 h-4 text-[#A7AD96]" />
                      <span>Added to Bag</span>
                    </>
                  ) : (
                    <>
                      <ShoppingBag className="w-4 h-4" />
                      <span>Add to Bag • ${(product.price * quantity).toLocaleString()}</span>
                    </>
                  )}
                </button>

                {/* Wishlist Button */}
                <button
                  onClick={() => onToggleWishlist(product)}
                  className={`p-3.5 rounded-lg border transition-colors flex items-center justify-center ${
                    isWishlisted
                      ? 'bg-[#4E5B43] border-[#4E5B43] text-white'
                      : 'border-[#E5E0D8] hover:border-[#24241F] text-[#6E6C65]'
                  }`}
                  aria-label="Save to wishlist"
                >
                  <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-current' : ''}`} />
                </button>
              </div>

              {/* Assurances */}
              <div className="grid grid-cols-2 gap-2 text-[11px] text-[#6E6C65] pt-2">
                <div className="flex items-center gap-1.5">
                  <Truck className="w-3.5 h-3.5 text-[#4E5B43]" />
                  <span>White-glove placement included</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <RotateCcw className="w-3.5 h-3.5 text-[#4E5B43]" />
                  <span>30-day in-home trial</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
