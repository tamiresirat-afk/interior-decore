import React from 'react';
import { ArrowRight, Compass, ShieldCheck, Sparkles, Leaf } from 'lucide-react';
import { BRAND_VALUES } from '../data/products';

interface CampaignBannerProps {
  onShopEditClick: () => void;
}

export const CampaignBanner: React.FC<CampaignBannerProps> = ({ onShopEditClick }) => {
  const iconMap: { [key: string]: React.ElementType } = {
    Compass: Compass,
    ShieldCheck: ShieldCheck,
    Sparkles: Sparkles,
    Leaf: Leaf
  };

  return (
    <section id="campaign-banner-section" className="w-full py-10 sm:py-16 bg-[#F7F4EE]">
      <div className="max-w-7xl mx-auto px-4 sm:px-8">
        <div className="rounded-2xl sm:rounded-3xl overflow-hidden border border-[#E5E0D8] shadow-lg grid grid-cols-1 lg:grid-cols-12 bg-white">
          {/* Left Side: Editorial Lifestyle Scene & Campaign Copy (7 cols) */}
          <div className="lg:col-span-7 relative min-h-[420px] sm:min-h-[480px] flex flex-col justify-end p-6 sm:p-10 lg:p-12 overflow-hidden group">
            {/* Background Lifestyle Image */}
            <div className="absolute inset-0 z-0">
              <img
                src="https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=1400&q=85"
                alt="Sophisticated interior vignette showing warm travertine console, sculptural lounge chair, ceramics and botanical branches"
                className="w-full h-full object-cover object-center transform transition-transform duration-700 group-hover:scale-103"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#26382C]/90 via-[#26382C]/50 to-black/10" />
            </div>

            {/* Campaign Text & CTA */}
            <div className="relative z-10 text-left max-w-lg">
              <span className="inline-block text-[11px] sm:text-xs font-semibold tracking-[0.25em] text-[#D9CDBD] uppercase mb-2 sm:mb-3">
                AUTUMN ARCHITECTURAL EDIT
              </span>
              <h2 className="font-serif-display text-3xl sm:text-4xl lg:text-5xl text-[#F7F4EE] font-normal leading-tight mb-3">
                Make Room for <br />
                <span className="italic">Better Living</span>
              </h2>
              <p className="text-[#EEE9DF]/90 text-sm sm:text-base leading-relaxed mb-6 font-normal">
                Enjoy up to 20% off selected pieces designed to bring warmth, natural texture, and architectural character into your home.
              </p>
              <button
                id="campaign-cta-button"
                onClick={onShopEditClick}
                className="inline-flex items-center gap-2.5 bg-[#F7F4EE] hover:bg-[#EEE9DF] text-[#26382C] px-6 py-3 rounded-lg text-xs sm:text-[13px] font-semibold tracking-wider uppercase transition-all duration-200 transform hover:scale-[1.02] shadow-sm"
              >
                <span>SHOP THE EDIT</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Right Side: Deep Olive / Forest Value Points 2x2 Grid (5 cols) */}
          <div className="lg:col-span-5 bg-[#26382C] text-[#F7F4EE] p-6 sm:p-10 lg:p-12 flex flex-col justify-between">
            <div>
              <span className="text-[11px] sm:text-xs font-semibold tracking-[0.22em] text-[#A7AD96] uppercase block mb-1">
                OUR COMMITMENTS
              </span>
              <h3 className="font-serif-display text-2xl sm:text-3xl text-white font-normal mb-8">
                Built with Integrity
              </h3>

              {/* 2x2 Value Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 sm:gap-8">
                {BRAND_VALUES.map((val, index) => {
                  const Icon = iconMap[val.iconName] || Sparkles;
                  return (
                    <div key={index} className="text-left space-y-2">
                      <div className="w-9 h-9 rounded-lg bg-[#4E5B43]/50 border border-[#A7AD96]/30 flex items-center justify-center text-[#D9CDBD]">
                        <Icon className="w-4.5 h-4.5" strokeWidth={1.75} />
                      </div>
                      <h4 className="font-serif-display text-lg text-white font-medium">
                        {val.title}
                      </h4>
                      <p className="text-xs text-[#EEE9DF]/80 leading-relaxed font-normal">
                        {val.description}
                      </p>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Subtle Brand Quote */}
            <div className="mt-8 pt-6 border-t border-[#A7AD96]/20 flex items-center justify-between text-[11px] text-[#A7AD96]">
              <span>Handcrafted in small ateliers</span>
              <span className="font-serif-display italic text-[#D9CDBD]">Vale & Oak</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
