import React from 'react';
import { Award, Truck, RotateCcw, Lock, Headphones } from 'lucide-react';

export const TrustPanel: React.FC = () => {
  const benefits = [
    {
      icon: Award,
      title: 'Premium Quality',
      description: 'Solid FSC-certified hardwoods, artisan joinery, and durable Belgian linens.'
    },
    {
      icon: Truck,
      title: 'Free Delivery',
      description: 'Complimentary white-glove placement on orders over $1,500.'
    },
    {
      icon: RotateCcw,
      title: 'Easy Returns',
      description: '30-day in-home trial period with hassle-free scheduled pickup.'
    },
    {
      icon: Lock,
      title: 'Secure Checkout',
      description: 'End-to-end 256-bit SSL encryption with biometric authentication.'
    },
    {
      icon: Headphones,
      title: 'Personal Support',
      description: 'Dedicated in-house interior consultants available seven days a week.'
    }
  ];

  return (
    <div className="relative z-20 max-w-7xl mx-auto px-4 sm:px-8 -mt-14 sm:-mt-18 mb-12 sm:mb-20">
      <div 
        id="floating-trust-panel"
        className="bg-white rounded-2xl shadow-md border border-[#E5E0D8] p-6 sm:p-8"
      >
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6 sm:gap-6 lg:gap-4 divide-y sm:divide-y-0 lg:divide-x divide-[#E5E0D8]/70">
          {benefits.map((item, index) => {
            const Icon = item.icon;
            return (
              <div 
                key={index} 
                className={`flex sm:flex-col items-center sm:items-start text-left gap-3.5 sm:gap-2.5 ${
                  index !== 0 ? 'pt-4 sm:pt-0 lg:pl-5' : ''
                }`}
              >
                <div className="w-10 h-10 rounded-full bg-[#F7F4EE] border border-[#E5E0D8] flex items-center justify-center text-[#4E5B43] flex-shrink-0">
                  <Icon className="w-4.5 h-4.5" strokeWidth={1.8} />
                </div>
                <div>
                  <h3 className="text-[13px] font-semibold tracking-wide text-[#24241F] mb-1">
                    {item.title}
                  </h3>
                  <p className="text-[12px] text-[#6E6C65] leading-relaxed font-normal">
                    {item.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
