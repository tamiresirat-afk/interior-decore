import React, { useState } from 'react';
import { X, CheckCircle, ShieldCheck, Truck, Lock, ArrowRight, Printer } from 'lucide-react';
import { CartItem } from '../types';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onOrderCompleted: () => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  items,
  onOrderCompleted
}) => {
  const [step, setStep] = useState<'details' | 'success'>('details');
  const [formData, setFormData] = useState({
    firstName: 'Elena',
    lastName: 'Rostova',
    email: 'elena.rostova@example.com',
    phone: '+1 (555) 234-8921',
    address: '742 Evergreen Terrace, Apt 4B',
    city: 'New York',
    state: 'NY',
    zip: '10012',
    deliveryInstructions: 'Elevator building, 4th floor. Call concierge upon arrival.'
  });
  const [orderNumber, setOrderNumber] = useState('');

  if (!isOpen) return null;

  const rawSubtotal = items.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const isFreeDelivery = rawSubtotal >= 1500;
  const shippingFee = isFreeDelivery ? 0 : 150;
  const total = rawSubtotal + shippingFee;

  const handlePlaceOrder = (e: React.FormEvent) => {
    e.preventDefault();
    const newOrderNum = 'VO-' + Math.floor(100000 + Math.random() * 900000);
    setOrderNumber(newOrderNum);
    setStep('success');
    onOrderCompleted();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
      <div 
        className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-[#E5E0D8] overflow-hidden z-10 my-auto text-left">
        {/* Header */}
        <div className="p-5 border-b border-[#E5E0D8] flex items-center justify-between bg-[#F7F4EE]">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded bg-[#26382C] text-white flex items-center justify-center text-xs font-serif-display">
              V
            </div>
            <h2 className="font-serif-display text-xl font-semibold text-[#24241F]">
              {step === 'details' ? 'Secure Checkout Simulation' : 'Order Confirmed'}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#6E6C65] hover:text-[#24241F] rounded-full hover:bg-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {step === 'details' ? (
          <form onSubmit={handlePlaceOrder} className="p-6 space-y-5 max-h-[80vh] overflow-y-auto">
            {/* Transparency Note */}
            <div className="bg-[#FDFBF7] border border-[#E5E0D8] p-3 rounded-lg flex items-start gap-2.5 text-xs text-[#6E6C65]">
              <Lock className="w-4 h-4 text-[#4E5B43] flex-shrink-0 mt-0.5" />
              <span>
                <strong>Demonstration Mode:</strong> Complete front-end checkout simulation. No live payments or real charges are processed.
              </span>
            </div>

            {/* Contact Information */}
            <div>
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#24241F] mb-3">
                1. Delivery & Contact Details
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block text-[#6E6C65] mb-1">First Name</label>
                  <input
                    type="text"
                    required
                    value={formData.firstName}
                    onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                    className="w-full bg-[#F7F4EE] border border-[#E5E0D8] rounded-md px-3 py-2 text-[#24241F] focus:outline-none focus:border-[#4E5B43]"
                  />
                </div>
                <div>
                  <label className="block text-[#6E6C65] mb-1">Last Name</label>
                  <input
                    type="text"
                    required
                    value={formData.lastName}
                    onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                    className="w-full bg-[#F7F4EE] border border-[#E5E0D8] rounded-md px-3 py-2 text-[#24241F] focus:outline-none focus:border-[#4E5B43]"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="block text-[#6E6C65] mb-1">Email for Delivery Updates</label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full bg-[#F7F4EE] border border-[#E5E0D8] rounded-md px-3 py-2 text-[#24241F] focus:outline-none focus:border-[#4E5B43]"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="block text-[#6E6C65] mb-1">Street Address</label>
                  <input
                    type="text"
                    required
                    value={formData.address}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                    className="w-full bg-[#F7F4EE] border border-[#E5E0D8] rounded-md px-3 py-2 text-[#24241F] focus:outline-none focus:border-[#4E5B43]"
                  />
                </div>
                <div>
                  <label className="block text-[#6E6C65] mb-1">City</label>
                  <input
                    type="text"
                    required
                    value={formData.city}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    className="w-full bg-[#F7F4EE] border border-[#E5E0D8] rounded-md px-3 py-2 text-[#24241F] focus:outline-none focus:border-[#4E5B43]"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[#6E6C65] mb-1">State</label>
                    <input
                      type="text"
                      required
                      value={formData.state}
                      onChange={(e) => setFormData({ ...formData, state: e.target.value })}
                      className="w-full bg-[#F7F4EE] border border-[#E5E0D8] rounded-md px-3 py-2 text-[#24241F] focus:outline-none focus:border-[#4E5B43]"
                    />
                  </div>
                  <div>
                    <label className="block text-[#6E6C65] mb-1">ZIP Code</label>
                    <input
                      type="text"
                      required
                      value={formData.zip}
                      onChange={(e) => setFormData({ ...formData, zip: e.target.value })}
                      className="w-full bg-[#F7F4EE] border border-[#E5E0D8] rounded-md px-3 py-2 text-[#24241F] focus:outline-none focus:border-[#4E5B43]"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Order Summary & Delivery */}
            <div className="pt-3 border-t border-[#E5E0D8]">
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#24241F] mb-2.5">
                2. Delivery Service Selection
              </h3>
              <div className="p-3.5 rounded-lg border border-[#4E5B43] bg-[#F7F4EE] flex items-center justify-between text-xs">
                <div className="flex items-center gap-2.5">
                  <Truck className="w-5 h-5 text-[#4E5B43]" />
                  <div>
                    <span className="font-semibold text-[#24241F] block">
                      White-Glove In-Home Placement & Packaging Removal
                    </span>
                    <span className="text-[#6E6C65] text-[11px]">
                      Scheduled appointment with 2-person delivery team
                    </span>
                  </div>
                </div>
                <span className="font-bold text-[#4E5B43]">
                  {isFreeDelivery ? 'COMPLIMENTARY' : `$${shippingFee}`}
                </span>
              </div>
            </div>

            {/* Totals */}
            <div className="pt-3 border-t border-[#E5E0D8] space-y-1.5 text-xs text-[#6E6C65]">
              <div className="flex justify-between">
                <span>Items ({items.length})</span>
                <span>${rawSubtotal.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span>Delivery</span>
                <span>{isFreeDelivery ? 'FREE' : `$${shippingFee}`}</span>
              </div>
              <div className="flex justify-between text-base font-semibold text-[#24241F] pt-2 border-t border-[#E5E0D8]">
                <span>Total Amount</span>
                <span>${total.toLocaleString()}</span>
              </div>
            </div>

            {/* Submit */}
            <button
              type="submit"
              className="w-full bg-[#26382C] hover:bg-[#19271E] text-white py-3.5 rounded-lg text-xs font-semibold tracking-wider uppercase transition-colors flex items-center justify-center gap-2 shadow-md"
            >
              <span>Place Simulated Order (${total.toLocaleString()})</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        ) : (
          <div className="p-8 text-center space-y-5 animate-in fade-in duration-300">
            <div className="w-16 h-16 rounded-full bg-[#F7F4EE] border border-[#4E5B43]/30 flex items-center justify-center text-[#4E5B43] mx-auto">
              <CheckCircle className="w-9 h-9" />
            </div>

            <div className="space-y-1">
              <span className="text-xs font-semibold uppercase tracking-widest text-[#4E5B43]">
                Order Confirmed
              </span>
              <h3 className="font-serif-display text-2xl sm:text-3xl text-[#24241F]">
                Thank you for your order, {formData.firstName}
              </h3>
              <p className="text-sm font-mono text-[#6E6C65]">
                Order Reference: <strong className="text-[#24241F]">{orderNumber}</strong>
              </p>
            </div>

            <div className="bg-[#F7F4EE] p-4 rounded-xl text-left text-xs space-y-2 border border-[#E5E0D8]">
              <div className="flex justify-between border-b border-[#E5E0D8] pb-2">
                <span className="text-[#6E6C65]">Delivery Address:</span>
                <span className="font-medium text-[#24241F]">{formData.address}, {formData.city}, {formData.state}</span>
              </div>
              <div className="flex justify-between border-b border-[#E5E0D8] pb-2">
                <span className="text-[#6E6C65]">Estimated Arrival Window:</span>
                <span className="font-medium text-[#4E5B43]">7–10 Business Days (White-Glove)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#6E6C65]">Confirmation Sent To:</span>
                <span className="font-medium text-[#24241F]">{formData.email}</span>
              </div>
            </div>

            <div className="flex gap-3 pt-2">
              <button
                onClick={() => window.print()}
                className="flex-1 py-3 border border-[#E5E0D8] hover:bg-[#F7F4EE] rounded-lg text-xs font-semibold text-[#24241F] flex items-center justify-center gap-1.5 transition-colors"
              >
                <Printer className="w-4 h-4" />
                <span>Print Receipt</span>
              </button>
              <button
                onClick={onClose}
                className="flex-1 py-3 bg-[#26382C] text-white rounded-lg text-xs font-semibold uppercase tracking-wider hover:bg-[#19271E] transition-colors"
              >
                Continue Shopping
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
