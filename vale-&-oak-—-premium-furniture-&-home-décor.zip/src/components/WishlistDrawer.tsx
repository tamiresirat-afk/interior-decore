import React from 'react';
import { X, Trash2, ShoppingBag, Heart, ArrowRight } from 'lucide-react';
import { Product } from '../types';

interface WishlistDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  wishlistProducts: Product[];
  onRemoveFromWishlist: (product: Product) => void;
  onAddToCart: (product: Product) => void;
  onQuickView: (product: Product) => void;
  onShopClick: () => void;
}

export const WishlistDrawer: React.FC<WishlistDrawerProps> = ({
  isOpen,
  onClose,
  wishlistProducts,
  onRemoveFromWishlist,
  onAddToCart,
  onQuickView,
  onShopClick
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/40 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      {/* Panel */}
      <div className="relative w-full max-w-md bg-white h-full shadow-2xl flex flex-col z-10 animate-in slide-in-from-right duration-300">
        <div className="p-5 border-b border-[#E5E0D8] flex items-center justify-between bg-[#F7F4EE]">
          <div className="flex items-center gap-2">
            <Heart className="w-5 h-5 text-[#4E5B43] fill-current" />
            <h2 className="font-serif-display text-xl font-semibold text-[#24241F]">
              Your Curated Wishlist
            </h2>
            <span className="text-xs text-[#6E6C65] font-medium">
              ({wishlistProducts.length})
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#6E6C65] hover:text-[#24241F] rounded-full hover:bg-white transition-colors"
            aria-label="Close wishlist"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {wishlistProducts.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-4">
              <div className="w-16 h-16 rounded-full bg-[#F7F4EE] border border-[#E5E0D8] flex items-center justify-center text-[#A99A87]">
                <Heart className="w-8 h-8 stroke-1" />
              </div>
              <div className="space-y-1">
                <h3 className="font-serif-display text-xl text-[#24241F]">No saved pieces yet</h3>
                <p className="text-xs text-[#6E6C65] max-w-xs">
                  Tap the heart icon on any product to save items for your future rooms.
                </p>
              </div>
              <button
                onClick={() => {
                  onClose();
                  onShopClick();
                }}
                className="bg-[#26382C] text-[#F7F4EE] px-6 py-2.5 rounded-lg text-xs font-semibold tracking-wider uppercase hover:bg-[#19271E] transition-colors"
              >
                Browse Collection
              </button>
            </div>
          ) : (
            wishlistProducts.map((product) => (
              <div 
                key={product.id}
                className="flex gap-4 pb-4 border-b border-[#E5E0D8]/70 text-left items-center"
              >
                <div 
                  onClick={() => {
                    onClose();
                    onQuickView(product);
                  }}
                  className="w-20 h-20 rounded-lg overflow-hidden bg-[#F7F4EE] border border-[#E5E0D8] flex-shrink-0 cursor-pointer"
                >
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover"
                  />
                </div>

                <div className="flex-1 min-w-0">
                  <h4 
                    onClick={() => {
                      onClose();
                      onQuickView(product);
                    }}
                    className="font-serif-display text-base font-medium text-[#24241F] hover:text-[#26382C] cursor-pointer truncate"
                  >
                    {product.name}
                  </h4>
                  <p className="text-xs font-semibold text-[#24241F] mt-0.5">
                    ${product.price.toLocaleString()}
                  </p>
                  <span className="text-[11px] text-[#4E5B43] block mt-1">In Stock • Ready for dispatch</span>
                </div>

                <div className="flex flex-col gap-2 flex-shrink-0">
                  <button
                    onClick={() => {
                      onAddToCart(product);
                      onRemoveFromWishlist(product);
                    }}
                    className="p-2 bg-[#26382C] text-white rounded-md hover:bg-[#19271E] transition-colors flex items-center justify-center text-xs"
                    title="Move to Bag"
                  >
                    <ShoppingBag className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => onRemoveFromWishlist(product)}
                    className="p-2 text-[#A99A87] hover:text-rose-600 rounded-md transition-colors flex items-center justify-center text-xs"
                    title="Remove from Wishlist"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {wishlistProducts.length > 0 && (
          <div className="p-4 border-t border-[#E5E0D8] bg-[#FDFBF7]">
            <button
              onClick={() => {
                wishlistProducts.forEach((p) => onAddToCart(p));
                onClose();
              }}
              className="w-full bg-[#26382C] hover:bg-[#19271E] text-white py-3 rounded-lg text-xs font-semibold tracking-wider uppercase transition-colors flex items-center justify-center gap-2"
            >
              <span>Add All to Bag</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
