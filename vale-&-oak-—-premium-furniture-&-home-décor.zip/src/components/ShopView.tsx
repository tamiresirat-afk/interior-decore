import React, { useState, useMemo } from 'react';
import { SlidersHorizontal, ArrowLeft, Check, Sparkles } from 'lucide-react';
import { Product } from '../types';
import { ProductCard } from './ProductCard';

interface ShopViewProps {
  products: Product[];
  initialCategory?: string;
  wishlistIds: string[];
  onToggleWishlist: (product: Product) => void;
  onAddToCart: (product: Product) => void;
  onQuickView: (product: Product) => void;
  onBackToHome: () => void;
}

export const ShopView: React.FC<ShopViewProps> = ({
  products,
  initialCategory,
  wishlistIds,
  onToggleWishlist,
  onAddToCart,
  onQuickView,
  onBackToHome
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>(initialCategory || 'All');
  const [selectedRoom, setSelectedRoom] = useState<string>('All');
  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc' | 'rating'>('featured');
  const [onlyInStock, setOnlyInStock] = useState(false);

  const categories = ['All', 'Living Room', 'Bedroom', 'Dining', 'Home Office', 'Storage', 'Lighting', 'Décor & Accents'];
  const rooms = ['All', 'Living', 'Dining', 'Bedroom', 'Office'];

  const filteredProducts = useMemo(() => {
    let list = [...products];

    if (selectedCategory !== 'All') {
      list = list.filter((p) => p.category === selectedCategory);
    }

    if (selectedRoom !== 'All') {
      list = list.filter((p) => p.room === selectedRoom);
    }

    if (onlyInStock) {
      list = list.filter((p) => p.inStock);
    }

    if (sortBy === 'price-asc') {
      list.sort((a, b) => a.price - b.price);
    } else if (sortBy === 'price-desc') {
      list.sort((a, b) => b.price - a.price);
    } else if (sortBy === 'rating') {
      list.sort((a, b) => b.rating - a.rating);
    }

    return list;
  }, [products, selectedCategory, selectedRoom, onlyInStock, sortBy]);

  return (
    <div id="shop-catalog-page" className="w-full bg-[#F7F4EE] min-h-screen pb-20 pt-4 sm:pt-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-8">
        {/* Breadcrumb & Back */}
        <div className="flex items-center gap-2 text-xs text-[#6E6C65] mb-6">
          <button 
            onClick={onBackToHome}
            className="flex items-center gap-1 hover:text-[#26382C] transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Home</span>
          </button>
          <span>/</span>
          <span className="text-[#24241F] font-medium">Shop Collection</span>
          {selectedCategory !== 'All' && (
            <>
              <span>/</span>
              <span className="text-[#4E5B43] font-semibold">{selectedCategory}</span>
            </>
          )}
        </div>

        {/* Page Title & Editorial Header */}
        <div className="mb-8 text-left">
          <span className="text-[11px] font-semibold tracking-[0.22em] text-[#4E5B43] uppercase block mb-1">
            THE VALE & OAK COLLECTION
          </span>
          <h1 className="font-serif-display text-3xl sm:text-4xl lg:text-5xl text-[#24241F] font-normal tracking-tight">
            {selectedCategory === 'All' ? 'All Furniture & Architectural Objects' : selectedCategory}
          </h1>
          <p className="text-[#6E6C65] text-sm sm:text-base mt-2 max-w-2xl font-normal">
            Every piece is tailored from honest materials: FSC-certified white oak, deep-grained walnut, pure Belgian flax, and artisan stoneware.
          </p>
        </div>

        {/* Filter Controls Bar */}
        <div className="bg-white rounded-xl border border-[#E5E0D8] p-4 mb-8 shadow-xs space-y-4">
          {/* Categories Pill Bar */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3.5 py-1.5 rounded-full text-xs font-medium tracking-wide transition-all whitespace-nowrap ${
                  selectedCategory === cat
                    ? 'bg-[#26382C] text-[#F7F4EE] shadow-2xs'
                    : 'bg-[#F7F4EE] text-[#6E6C65] hover:text-[#24241F] hover:bg-[#EEE9DF]'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Secondary Controls (Room, In-Stock, Sort) */}
          <div className="flex flex-wrap items-center justify-between gap-4 pt-3 border-t border-[#E5E0D8]/70 text-xs">
            <div className="flex flex-wrap items-center gap-3">
              {/* Room Filter */}
              <div className="flex items-center gap-1.5">
                <span className="text-[#A99A87] uppercase text-[10px] font-semibold tracking-wider">Room:</span>
                <div className="flex gap-1">
                  {rooms.map((room) => (
                    <button
                      key={room}
                      onClick={() => setSelectedRoom(room)}
                      className={`px-2.5 py-1 rounded text-[11px] ${
                        selectedRoom === room 
                          ? 'bg-[#4E5B43] text-white font-medium' 
                          : 'text-[#6E6C65] hover:bg-[#F7F4EE]'
                      }`}
                    >
                      {room}
                    </button>
                  ))}
                </div>
              </div>

              {/* In Stock Only Checkbox */}
              <label className="flex items-center gap-2 cursor-pointer select-none text-[#24241F] ml-2">
                <input
                  type="checkbox"
                  checked={onlyInStock}
                  onChange={(e) => setOnlyInStock(e.target.checked)}
                  className="rounded border-[#A99A87] text-[#26382C] focus:ring-0 w-3.5 h-3.5"
                />
                <span className="text-xs">In Stock Only</span>
              </label>
            </div>

            {/* Sort & Count */}
            <div className="flex items-center gap-4">
              <span className="text-[#6E6C65]">
                Showing <strong>{filteredProducts.length}</strong> items
              </span>
              <div className="flex items-center gap-2">
                <span className="text-[#A99A87] uppercase text-[10px] font-semibold tracking-wider">Sort by:</span>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as any)}
                  className="bg-[#F7F4EE] border border-[#E5E0D8] rounded-md px-2.5 py-1 text-xs text-[#24241F] focus:outline-none focus:border-[#4E5B43]"
                >
                  <option value="featured">Featured Curations</option>
                  <option value="price-asc">Price: Low to High</option>
                  <option value="price-desc">Price: High to Low</option>
                  <option value="rating">Highest Customer Rating</option>
                </select>
              </div>
            </div>
          </div>
        </div>

        {/* Product Grid */}
        {filteredProducts.length === 0 ? (
          <div className="bg-white rounded-2xl border border-[#E5E0D8] p-12 text-center my-8">
            <Sparkles className="w-8 h-8 text-[#A99A87] mx-auto mb-3 stroke-1" />
            <h3 className="font-serif-display text-xl text-[#24241F] mb-1">No matching pieces in this selection</h3>
            <p className="text-xs text-[#6E6C65] max-w-sm mx-auto mb-4">
              Try adjusting your category or room filters to discover available pieces.
            </p>
            <button
              onClick={() => {
                setSelectedCategory('All');
                setSelectedRoom('All');
                setOnlyInStock(false);
              }}
              className="px-4 py-2 bg-[#26382C] text-white rounded-lg text-xs font-semibold uppercase tracking-wider"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                isWishlisted={wishlistIds.includes(product.id)}
                onToggleWishlist={onToggleWishlist}
                onAddToCart={onAddToCart}
                onQuickView={onQuickView}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
