import React from 'react';
import { ArrowRight } from 'lucide-react';
import { Product } from '../types';
import { ProductCard } from './ProductCard';

interface ProductGridProps {
  products: Product[];
  wishlistIds: string[];
  onToggleWishlist: (product: Product) => void;
  onAddToCart: (product: Product) => void;
  onQuickView: (product: Product) => void;
  onViewAllClick: () => void;
}

export const ProductGrid: React.FC<ProductGridProps> = ({
  products,
  wishlistIds,
  onToggleWishlist,
  onAddToCart,
  onQuickView,
  onViewAllClick
}) => {
  // Take first 6 products for homepage featured showcase
  const featuredProducts = products.slice(0, 6);

  return (
    <section id="featured-products-section" className="w-full py-12 sm:py-20 bg-[#F7F4EE]">
      <div className="max-w-7xl mx-auto px-4 sm:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 sm:mb-12 gap-4 pb-4 border-b border-[#E5E0D8]">
          <div>
            <span className="text-[11px] sm:text-xs font-semibold tracking-[0.22em] text-[#4E5B43] uppercase block mb-1.5">
              OUR PICKS
            </span>
            <h2 className="font-serif-display text-3xl sm:text-4xl text-[#24241F] font-normal tracking-tight">
              Featured Pieces
            </h2>
            <p className="text-[#6E6C65] text-sm sm:text-base mt-2 max-w-xl font-normal">
              Considered designs chosen for comfort, craftsmanship and timeless appeal. Each piece is made to last for generations.
            </p>
          </div>

          <button
            onClick={onViewAllClick}
            className="inline-flex items-center gap-2 text-xs sm:text-[13px] font-semibold text-[#26382C] hover:text-[#4E5B43] tracking-wider uppercase transition-colors group self-start md:self-auto py-1"
          >
            <span>VIEW ALL PRODUCTS</span>
            <ArrowRight className="w-4 h-4 transition-transform duration-200 group-hover:translate-x-1" />
          </button>
        </div>

        {/* 6 Product Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {featuredProducts.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              isWishlisted={wishlistIds.includes(product.id)}
              onToggleWishlist={onToggleWishlist}
              onAddToCart={onAddToCart}
              onQuickView={onQuickView}
            />
          ))}
        </div>
      </div>
    </section>
  );
};
