import React from 'react';
import { X, ArrowRight, Compass } from 'lucide-react';
import { ROOM_STORIES, PRODUCTS } from '../data/products';
import { Product } from '../types';

interface RoomsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onQuickView: (product: Product) => void;
  onShopClick: () => void;
}

export const RoomsModal: React.FC<RoomsModalProps> = ({
  isOpen,
  onClose,
  onQuickView,
  onShopClick
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
      <div 
        className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      <div className="relative w-full max-w-4xl bg-[#F7F4EE] rounded-2xl sm:rounded-3xl shadow-2xl border border-[#E5E0D8] overflow-hidden z-10 my-auto text-left max-h-[85vh] flex flex-col">
        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-[#E5E0D8] flex items-center justify-between bg-white flex-shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-[#4E5B43] text-[#F7F4EE] flex items-center justify-center">
              <Compass className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-serif-display text-xl sm:text-2xl font-semibold text-[#24241F]">
                Curated Room Architecture
              </h2>
              <span className="text-xs text-[#6E6C65]">
                Harmonious interior compositions styled by our design studio
              </span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#6E6C65] hover:text-[#24241F] rounded-full hover:bg-[#F7F4EE] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Room Stories List */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-8 space-y-8">
          {ROOM_STORIES.map((story) => {
            const featuredItems = PRODUCTS.filter((p) => story.featuredProductIds.includes(p.id));

            return (
              <div key={story.id} className="bg-white rounded-2xl border border-[#E5E0D8] overflow-hidden shadow-xs">
                <div className="relative h-64 sm:h-80 w-full overflow-hidden">
                  <img
                    src={story.image}
                    alt={story.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
                  <div className="absolute bottom-5 left-5 right-5 text-white">
                    <span className="text-[10px] font-semibold uppercase tracking-widest text-[#D9CDBD] block mb-1">
                      {story.room}
                    </span>
                    <h3 className="font-serif-display text-2xl sm:text-3xl font-medium">
                      {story.title}
                    </h3>
                    <p className="text-xs sm:text-sm text-[#EEE9DF] max-w-lg mt-1 font-light italic">
                      "{story.quote}"
                    </p>
                  </div>
                </div>

                {/* Hotspot Products in this room */}
                <div className="p-5 sm:p-6 bg-[#FDFBF7]">
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-[#24241F] mb-3">
                    Pieces In This Room
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
                    {featuredItems.map((prod) => (
                      <div
                        key={prod.id}
                        onClick={() => {
                          onClose();
                          onQuickView(prod);
                        }}
                        className="flex items-center gap-3 p-2 rounded-lg bg-white border border-[#E5E0D8] hover:border-[#4E5B43] transition-all cursor-pointer group"
                      >
                        <img
                          src={prod.image}
                          alt={prod.name}
                          className="w-12 h-12 rounded object-cover flex-shrink-0"
                        />
                        <div className="min-w-0 flex-1 text-left">
                          <h5 className="font-serif-display text-xs font-medium text-[#24241F] group-hover:text-[#26382C] truncate">
                            {prod.name}
                          </h5>
                          <span className="text-[11px] font-semibold text-[#24241F] block">
                            ${prod.price.toLocaleString()}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-[#E5E0D8] bg-white flex justify-between items-center text-xs">
          <span className="text-[#6E6C65]">Looking for customized interior layout advice?</span>
          <button
            onClick={() => {
              onClose();
              onShopClick();
            }}
            className="px-4 py-2 bg-[#26382C] text-white rounded-lg text-xs font-semibold uppercase tracking-wider hover:bg-[#19271E] transition-colors flex items-center gap-1.5"
          >
            <span>Browse All Collections</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
