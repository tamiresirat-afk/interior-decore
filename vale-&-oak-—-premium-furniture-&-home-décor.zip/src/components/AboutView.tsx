import React from 'react';
import { ArrowLeft, ShieldCheck, TreePine, Award, Users } from 'lucide-react';

interface AboutViewProps {
  onBackToHome: () => void;
  onShopClick: () => void;
}

export const AboutView: React.FC<AboutViewProps> = ({ onBackToHome, onShopClick }) => {
  return (
    <div id="about-page" className="w-full bg-[#F7F4EE] min-h-screen pb-20 pt-4 sm:pt-6 text-left">
      <div className="max-w-7xl mx-auto px-4 sm:px-8">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-xs text-[#6E6C65] mb-6">
          <button onClick={onBackToHome} className="flex items-center gap-1 hover:text-[#26382C]">
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Home</span>
          </button>
          <span>/</span>
          <span className="text-[#24241F] font-medium">About Vale & Oak</span>
        </div>

        {/* Hero Section */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center mb-16 border-b border-[#E5E0D8] pb-12">
          <div className="lg:col-span-7">
            <span className="text-[11px] font-semibold tracking-[0.22em] text-[#4E5B43] uppercase block mb-2">
              OUR ATELIER PHILOSOPHY
            </span>
            <h1 className="font-serif-display text-4xl sm:text-5xl lg:text-6xl text-[#24241F] font-normal leading-[1.1] mb-6">
              Furniture Crafted for <br />
              <span className="italic text-[#26382C]">Generations, Not Seasons</span>
            </h1>
            <p className="text-[#6E6C65] text-base sm:text-lg leading-relaxed mb-4">
              Founded on the belief that modern homes deserve quiet, enduring objects made from authentic materials, Vale & Oak pairs architectural proportions with centuries-old joinery traditions.
            </p>
            <p className="text-[#6E6C65] text-sm leading-relaxed">
              We reject transient fast-furniture cycles and disposable veneer boards. Instead, our workshops select FSC-certified European white oaks, Appalachian black walnuts, and washed Belgian linens that grow more luminous with every passing decade.
            </p>
          </div>

          <div className="lg:col-span-5 rounded-2xl overflow-hidden shadow-lg border border-[#E5E0D8] aspect-4/5">
            <img
              src="https://images.unsplash.com/photo-1538688525198-9b88f6f53126?auto=format&fit=crop&w=1000&q=85"
              alt="Artisan cabinetmaker hand-planing solid European white oak board in workshop"
              className="w-full h-full object-cover"
            />
          </div>
        </div>

        {/* Pillars Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          <div className="bg-white p-8 rounded-2xl border border-[#E5E0D8] shadow-2xs space-y-3">
            <div className="w-10 h-10 rounded-full bg-[#F7F4EE] border border-[#E5E0D8] flex items-center justify-center text-[#4E5B43]">
              <TreePine className="w-5 h-5" />
            </div>
            <h3 className="font-serif-display text-xl text-[#24241F]">FSC-Certified Forestry</h3>
            <p className="text-xs text-[#6E6C65] leading-relaxed">
              All timber originates from sustainably managed forests in France, Germany, and Pennsylvania, with strict replanting ratios and continuous canopy preservation.
            </p>
          </div>

          <div className="bg-white p-8 rounded-2xl border border-[#E5E0D8] shadow-2xs space-y-3">
            <div className="w-10 h-10 rounded-full bg-[#F7F4EE] border border-[#E5E0D8] flex items-center justify-center text-[#4E5B43]">
              <Award className="w-5 h-5" />
            </div>
            <h3 className="font-serif-display text-xl text-[#24241F]">Traditional Joinery</h3>
            <p className="text-xs text-[#6E6C65] leading-relaxed">
              Mortise-and-tenon joints, blind dovetails, and solid timber dowels allow wood to expand and contract naturally with seasonal humidity without warping or joint fatigue.
            </p>
          </div>

          <div className="bg-white p-8 rounded-2xl border border-[#E5E0D8] shadow-2xs space-y-3">
            <div className="w-10 h-10 rounded-full bg-[#F7F4EE] border border-[#E5E0D8] flex items-center justify-center text-[#4E5B43]">
              <Users className="w-5 h-5" />
            </div>
            <h3 className="font-serif-display text-xl text-[#24241F]">Independent Workshops</h3>
            <p className="text-xs text-[#6E6C65] leading-relaxed">
              We partner directly with multigenerational family-owned woodshops and ceramic studios in Portugal, Denmark, and the Hudson Valley, ensuring living wages and master craftsmanship.
            </p>
          </div>
        </div>

        {/* CTA */}
        <div className="bg-[#26382C] text-[#F7F4EE] p-8 sm:p-12 rounded-3xl text-center space-y-4">
          <h2 className="font-serif-display text-3xl sm:text-4xl">
            Bring Quiet Craft Into Your Home
          </h2>
          <p className="text-sm text-[#D9CDBD] max-w-xl mx-auto">
            Discover pieces designed to become permanent centerpieces of your living and dining rituals.
          </p>
          <button
            onClick={onShopClick}
            className="px-8 py-3.5 bg-[#F7F4EE] text-[#26382C] rounded-lg text-xs font-semibold uppercase tracking-wider hover:bg-white transition-colors inline-block"
          >
            Explore the Collection
          </button>
        </div>
      </div>
    </div>
  );
};
