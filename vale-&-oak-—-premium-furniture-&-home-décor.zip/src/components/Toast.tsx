import React from 'react';
import { Check, Heart, ShoppingBag, X } from 'lucide-react';

export interface ToastMessage {
  id: string;
  type: 'cart' | 'wishlist' | 'info';
  title: string;
  subtitle?: string;
}

interface ToastProps {
  toasts: ToastMessage[];
  onDismiss: (id: string) => void;
  onOpenCart?: () => void;
}

export const ToastContainer: React.FC<ToastProps> = ({ toasts, onDismiss, onOpenCart }) => {
  if (toasts.length === 0) return null;

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-2.5 max-w-sm w-full pointer-events-none">
      {toasts.map((t) => (
        <div
          key={t.id}
          className="pointer-events-auto bg-white border border-[#E5E0D8] rounded-xl shadow-xl p-3.5 flex items-center gap-3 animate-in slide-in-from-bottom-3 fade-in duration-200 text-left"
        >
          <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
            t.type === 'cart' 
              ? 'bg-[#26382C] text-white' 
              : t.type === 'wishlist'
              ? 'bg-[#4E5B43] text-white'
              : 'bg-[#F7F4EE] text-[#24241F]'
          }`}>
            {t.type === 'cart' ? (
              <ShoppingBag className="w-4 h-4" />
            ) : t.type === 'wishlist' ? (
              <Heart className="w-4 h-4 fill-current" />
            ) : (
              <Check className="w-4 h-4" />
            )}
          </div>

          <div className="flex-1 min-w-0">
            <h4 className="text-xs font-semibold text-[#24241F] truncate">
              {t.title}
            </h4>
            {t.subtitle && (
              <p className="text-[11px] text-[#6E6C65] truncate">
                {t.subtitle}
              </p>
            )}
          </div>

          {t.type === 'cart' && onOpenCart && (
            <button
              onClick={onOpenCart}
              className="text-[11px] font-bold text-[#26382C] hover:underline uppercase tracking-wider flex-shrink-0"
            >
              View Bag
            </button>
          )}

          <button
            onClick={() => onDismiss(t.id)}
            className="text-[#A99A87] hover:text-[#24241F] p-1 flex-shrink-0"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      ))}
    </div>
  );
};
