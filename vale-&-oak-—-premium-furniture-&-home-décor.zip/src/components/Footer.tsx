import React from 'react';
import { Instagram, Facebook, PinIcon as Pinterest, Youtube } from 'lucide-react';
import { ActiveView } from '../types';

interface FooterProps {
  onNavigate: (view: ActiveView, category?: string) => void;
  onOpenContactModal?: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate, onOpenContactModal }) => {
  return (
    <footer id="main-site-footer" className="w-full bg-[#EEE9DF]/70 border-t border-[#E5E0D8] text-[#24241F] pt-14 sm:pt-20 pb-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-8">
        {/* 5 Columns Layout */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 lg:gap-8 pb-14 border-b border-[#E5E0D8]">
          {/* Column 1: Brand & Bio */}
          <div className="lg:col-span-1 space-y-4 text-left">
            <div className="flex items-center gap-2.5">
              <div className="w-7 h-7 rounded-sm bg-[#26382C] text-[#F7F4EE] flex items-center justify-center">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" className="w-4 h-4">
                  <path d="M4 21V10a8 8 0 0 1 16 0v11" />
                  <path d="M4 21h16" />
                  <path d="M9 21v-7a3 3 0 0 1 6 0v7" />
                </svg>
              </div>
              <span className="font-serif-display text-xl tracking-widest font-semibold text-[#24241F]">
                VALE & OAK
              </span>
            </div>

            <p className="text-xs text-[#6E6C65] leading-relaxed font-normal">
              Atelier of considered furnishings, organic textiles, and architectural objects crafted to bring quiet warmth and enduring harmony into the home.
            </p>

            {/* Social Icons */}
            <div className="flex items-center gap-3 text-[#6E6C65] pt-1">
              <a 
                href="#instagram" 
                onClick={(e) => e.preventDefault()} 
                className="w-8 h-8 rounded-full bg-white border border-[#E5E0D8] flex items-center justify-center hover:text-[#26382C] hover:border-[#26382C] transition-colors"
                aria-label="Vale & Oak on Instagram"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a 
                href="#pinterest" 
                onClick={(e) => e.preventDefault()} 
                className="w-8 h-8 rounded-full bg-white border border-[#E5E0D8] flex items-center justify-center hover:text-[#26382C] hover:border-[#26382C] transition-colors"
                aria-label="Vale & Oak on Pinterest"
              >
                <Pinterest className="w-4 h-4" />
              </a>
              <a 
                href="#facebook" 
                onClick={(e) => e.preventDefault()} 
                className="w-8 h-8 rounded-full bg-white border border-[#E5E0D8] flex items-center justify-center hover:text-[#26382C] hover:border-[#26382C] transition-colors"
                aria-label="Vale & Oak on Facebook"
              >
                <Facebook className="w-4 h-4" />
              </a>
              <a 
                href="#youtube" 
                onClick={(e) => e.preventDefault()} 
                className="w-8 h-8 rounded-full bg-white border border-[#E5E0D8] flex items-center justify-center hover:text-[#26382C] hover:border-[#26382C] transition-colors"
                aria-label="Vale & Oak Studio film on YouTube"
              >
                <Youtube className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Column 2: SHOP */}
          <div className="text-left space-y-3">
            <h4 className="text-[11px] font-bold uppercase tracking-widest text-[#24241F]">
              Shop Departments
            </h4>
            <ul className="space-y-2 text-xs text-[#6E6C65]">
              <li>
                <button onClick={() => onNavigate('shop', 'Living Room')} className="hover:text-[#26382C] transition-colors">
                  Living Room Seating
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('shop', 'Bedroom')} className="hover:text-[#26382C] transition-colors">
                  Solid Oak Beds & Linen
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('shop', 'Dining')} className="hover:text-[#26382C] transition-colors">
                  Dining Tables & Benches
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('shop', 'Home Office')} className="hover:text-[#26382C] transition-colors">
                  Home Office Desks
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('shop', 'Storage')} className="hover:text-[#26382C] transition-colors">
                  Credenzas & Storage
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('shop', 'Lighting')} className="hover:text-[#26382C] transition-colors">
                  Alabaster & Ceramic Lighting
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('shop', 'Décor & Accents')} className="hover:text-[#26382C] transition-colors">
                  Handmade Ceramics & Rugs
                </button>
              </li>
            </ul>
          </div>

          {/* Column 3: CUSTOMER CARE */}
          <div className="text-left space-y-3">
            <h4 className="text-[11px] font-bold uppercase tracking-widest text-[#24241F]">
              Client Concierge
            </h4>
            <ul className="space-y-2 text-xs text-[#6E6C65]">
              <li>
                <button onClick={() => onOpenContactModal ? onOpenContactModal() : onNavigate('about')} className="hover:text-[#26382C] transition-colors">
                  Track Delivery
                </button>
              </li>
              <li>
                <button onClick={() => onOpenContactModal ? onOpenContactModal() : onNavigate('about')} className="hover:text-[#26382C] transition-colors">
                  White-Glove Shipping
                </button>
              </li>
              <li>
                <button onClick={() => onOpenContactModal ? onOpenContactModal() : onNavigate('about')} className="hover:text-[#26382C] transition-colors">
                  30-Day In-Home Returns
                </button>
              </li>
              <li>
                <button onClick={() => onOpenContactModal ? onOpenContactModal() : onNavigate('about')} className="hover:text-[#26382C] transition-colors">
                  Timber & Linen Care Guide
                </button>
              </li>
              <li>
                <button onClick={() => onOpenContactModal ? onOpenContactModal() : onNavigate('about')} className="hover:text-[#26382C] transition-colors">
                  Frequently Asked Questions
                </button>
              </li>
              <li>
                <button onClick={() => onOpenContactModal ? onOpenContactModal() : onNavigate('about')} className="hover:text-[#26382C] transition-colors">
                  Interior Trade Program
                </button>
              </li>
            </ul>
          </div>

          {/* Column 4: COMPANY */}
          <div className="text-left space-y-3">
            <h4 className="text-[11px] font-bold uppercase tracking-widest text-[#24241F]">
              The Atelier
            </h4>
            <ul className="space-y-2 text-xs text-[#6E6C65]">
              <li>
                <button onClick={() => onNavigate('about')} className="hover:text-[#26382C] transition-colors">
                  Our Story & Philosophy
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('journal')} className="hover:text-[#26382C] transition-colors">
                  The Design Journal
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('about')} className="hover:text-[#26382C] transition-colors">
                  Artisans & Wood Joinery
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('about')} className="hover:text-[#26382C] transition-colors">
                  FSC Timber Sustainability
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('about')} className="hover:text-[#26382C] transition-colors">
                  Studio Careers
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('about')} className="hover:text-[#26382C] transition-colors">
                  Press Inquiries
                </button>
              </li>
            </ul>
          </div>

          {/* Column 5: CONTACT */}
          <div className="text-left space-y-3">
            <h4 className="text-[11px] font-bold uppercase tracking-widest text-[#24241F]">
              Contact & Showrooms
            </h4>
            <div className="text-xs text-[#6E6C65] space-y-2.5">
              <div>
                <span className="block font-medium text-[#24241F]">Client Services</span>
                <span className="text-[#4E5B43]">concierge@valeandoak.com</span>
              </div>
              <div>
                <span className="block font-medium text-[#24241F]">Phone & WhatsApp</span>
                <span>+1 (800) 412-8920</span>
                <span className="block text-[11px] text-[#A99A87]">Mon–Sat 9am–7pm EST</span>
              </div>
              <div>
                <span className="block font-medium text-[#24241F]">Main Design Studio</span>
                <span>482 Crosby Street, 4th Floor</span>
                <span className="block">SoHo, New York, NY 10012</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Legal & Payment Indicators */}
        <div className="pt-8 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-[#6E6C65]">
          <div>
            © {new Date().getFullYear()} Vale & Oak Atelier Inc. All rights reserved. Designed for beautiful living.
          </div>

          <div className="flex items-center gap-5 text-[11px]">
            <a href="#privacy" onClick={(e) => e.preventDefault()} className="hover:text-[#24241F] transition-colors">Privacy Policy</a>
            <span>•</span>
            <a href="#terms" onClick={(e) => e.preventDefault()} className="hover:text-[#24241F] transition-colors">Terms of Service</a>
            <span>•</span>
            <a href="#cookies" onClick={(e) => e.preventDefault()} className="hover:text-[#24241F] transition-colors">Cookie Preferences</a>
          </div>

          {/* Clean Payment Indicators (Visa, Mastercard, Amex, PayPal, Apple Pay, Google Pay) */}
          <div className="flex items-center gap-2">
            <span className="px-2 py-1 bg-white border border-[#E5E0D8] rounded text-[10px] font-bold text-[#1A1F71] tracking-wider">
              VISA
            </span>
            <span className="px-2 py-1 bg-white border border-[#E5E0D8] rounded text-[10px] font-bold text-[#EB001B] tracking-wider">
              MC
            </span>
            <span className="px-2 py-1 bg-white border border-[#E5E0D8] rounded text-[10px] font-bold text-[#006FCF] tracking-wider">
              AMEX
            </span>
            <span className="px-2 py-1 bg-white border border-[#E5E0D8] rounded text-[10px] font-bold text-[#003087] tracking-wider">
              PayPal
            </span>
            <span className="px-2 py-1 bg-white border border-[#E5E0D8] rounded text-[10px] font-bold text-[#24241F] tracking-wider">
              Pay
            </span>
            <span className="px-2 py-1 bg-white border border-[#E5E0D8] rounded text-[10px] font-bold text-[#4285F4] tracking-wider">
              GPay
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
};
