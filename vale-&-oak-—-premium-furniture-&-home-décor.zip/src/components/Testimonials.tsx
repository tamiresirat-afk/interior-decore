import React, { useState, useEffect } from 'react';
import { Star, ChevronLeft, ChevronRight, CheckCircle } from 'lucide-react';
import { TESTIMONIALS } from '../data/products';

export const Testimonials: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  useEffect(() => {
    if (isPaused) return;

    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % TESTIMONIALS.length);
    }, 6000);

    return () => clearInterval(interval);
  }, [isPaused]);

  const current = TESTIMONIALS[currentIndex];

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev - 1 + TESTIMONIALS.length) % TESTIMONIALS.length);
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % TESTIMONIALS.length);
  };

  return (
    <section 
      id="testimonials-section" 
      className="w-full py-12 sm:py-20 bg-[#F7F4EE]"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
      onTouchStart={() => setIsPaused(true)}
      onTouchEnd={() => setIsPaused(false)}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-8">
        <div className="bg-white rounded-2xl sm:rounded-3xl border border-[#E5E0D8] shadow-sm overflow-hidden grid grid-cols-1 lg:grid-cols-12">
          {/* Left Column: Styled Interior Image (5 cols) */}
          <div className="lg:col-span-5 relative min-h-[300px] sm:min-h-[400px] lg:min-h-[480px]">
            <img
              src={current.interiorImage}
              alt={`Client interior featuring ${current.productPurchased}`}
              className="w-full h-full object-cover object-center transition-all duration-700 ease-out"
              loading="lazy"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent lg:hidden" />
            <div className="absolute bottom-4 left-4 right-4 text-white text-xs lg:text-[#24241F] lg:bg-white/90 lg:backdrop-blur-xs lg:bottom-4 lg:left-4 lg:right-auto lg:px-3 lg:py-1.5 lg:rounded-md lg:border lg:border-[#E5E0D8] z-10">
              <span className="font-semibold block text-[11px] uppercase tracking-wider text-[#D9CDBD] lg:text-[#4E5B43]">
                Verified Interior Placement
              </span>
              <span className="text-[12px] opacity-90 lg:opacity-100 font-medium">
                {current.productPurchased}
              </span>
            </div>
          </div>

          {/* Right Column: Editorial Testimonial Carousel (7 cols) */}
          <div className="lg:col-span-7 p-6 sm:p-10 lg:p-14 flex flex-col justify-between relative">
            {/* Subtle Large Decorative Quotation Mark */}
            <div className="absolute top-6 right-8 text-[#EEE9DF] font-serif-display text-8xl sm:text-9xl leading-none select-none pointer-events-none -z-0">
              “
            </div>

            <div className="relative z-10 text-left">
              {/* Star Rating & Verified Label */}
              <div className="flex items-center gap-2 mb-4">
                <div className="flex text-[#C49E68]">
                  {[...Array(current.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-current" />
                  ))}
                </div>
                <div className="flex items-center gap-1 text-[11px] text-[#4E5B43] font-semibold tracking-wide ml-2 bg-[#F7F4EE] px-2 py-0.5 rounded-full border border-[#E5E0D8]">
                  <CheckCircle className="w-3 h-3" />
                  <span>Verified Purchase</span>
                </div>
              </div>

              {/* Testimonial Quote */}
              <blockquote className="font-serif-display text-xl sm:text-2xl lg:text-[28px] text-[#24241F] leading-relaxed font-normal mb-8 transition-opacity duration-300">
                “{current.quote}”
              </blockquote>

              {/* Author Info */}
              <div className="mb-6">
                <div className="font-serif-display text-lg font-semibold text-[#26382C]">
                  {current.author}
                </div>
                <div className="text-xs text-[#6E6C65] tracking-wide">
                  {current.city}
                </div>
              </div>
            </div>

            {/* Carousel Navigation Controls & Indicators */}
            <div className="relative z-10 flex items-center justify-between pt-6 border-t border-[#E5E0D8]/80">
              {/* Dots Indicator */}
              <div className="flex items-center gap-2">
                {TESTIMONIALS.map((_, dotIdx) => (
                  <button
                    key={dotIdx}
                    onClick={() => setCurrentIndex(dotIdx)}
                    className={`h-1.5 rounded-full transition-all duration-300 ${
                      currentIndex === dotIdx 
                        ? 'w-6 bg-[#26382C]' 
                        : 'w-1.5 bg-[#D9CDBD] hover:bg-[#A99A87]'
                    }`}
                    aria-label={`Go to testimonial ${dotIdx + 1}`}
                  />
                ))}
              </div>

              {/* Arrow Buttons */}
              <div className="flex items-center gap-2">
                <button
                  onClick={handlePrev}
                  className="w-9 h-9 rounded-full border border-[#E5E0D8] hover:border-[#24241F] hover:bg-[#F7F4EE] text-[#24241F] flex items-center justify-center transition-colors"
                  aria-label="Previous testimonial"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  onClick={handleNext}
                  className="w-9 h-9 rounded-full border border-[#E5E0D8] hover:border-[#24241F] hover:bg-[#F7F4EE] text-[#24241F] flex items-center justify-center transition-colors"
                  aria-label="Next testimonial"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
