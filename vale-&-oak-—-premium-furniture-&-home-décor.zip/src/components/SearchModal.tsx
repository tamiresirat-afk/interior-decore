import React, { useState, useMemo } from 'react';
import { Search, X, ArrowRight } from 'lucide-react';
import { Product } from '../types';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  onSelectProduct: (product: Product) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  products,
  onSelectProduct
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const quickPills = ['Oak Dining', 'Linen Sofas', 'Table Lamp', 'Walnut', 'Armchairs', 'Under $1,000'];

  const filtered = useMemo(() => {
    return products.filter((p) => {
      const matchesText = 
        p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.materials.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.description.toLowerCase().includes(searchTerm.toLowerCase());

      const matchesCategory = selectedCategory ? p.category === selectedCategory : true;

      return matchesText && matchesCategory;
    });
  }, [products, searchTerm, selectedCategory]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-10 sm:pt-20 px-4">
      <div 
        className="fixed inset-0 bg-black/50 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-[#E5E0D8] overflow-hidden z-10 animate-in fade-in zoom-in-95 duration-200">
        {/* Search Bar */}
        <div className="p-4 sm:p-6 border-b border-[#E5E0D8] flex items-center gap-3 bg-[#F7F4EE]">
          <Search className="w-5 h-5 text-[#4E5B43] flex-shrink-0" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search chairs, dining tables, lamps, linens, walnut..."
            autoFocus
            className="flex-1 bg-transparent text-base sm:text-lg text-[#24241F] placeholder:text-[#A99A87] focus:outline-none"
          />
          {searchTerm && (
            <button
              onClick={() => setSearchTerm('')}
              className="text-[#A99A87] hover:text-[#24241F] text-xs p-1"
            >
              Clear
            </button>
          )}
          <button
            onClick={onClose}
            className="p-1.5 text-[#6E6C65] hover:text-[#24241F] rounded-full hover:bg-white transition-colors"
            aria-label="Close search"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Suggestion Pills */}
        <div className="px-5 py-3 border-b border-[#E5E0D8]/60 bg-[#FDFBF7] flex items-center gap-2 overflow-x-auto no-scrollbar">
          <span className="text-[11px] uppercase tracking-wider text-[#A99A87] font-semibold flex-shrink-0">
            Suggested:
          </span>
          {quickPills.map((pill) => (
            <button
              key={pill}
              onClick={() => {
                if (pill === 'Under $1,000') {
                  setSearchTerm('chair');
                } else {
                  setSearchTerm(pill.replace(' Dining', '').replace(' Sofas', ''));
                }
              }}
              className="px-2.5 py-1 rounded-full bg-white border border-[#E5E0D8] text-[11px] text-[#6E6C65] hover:text-[#26382C] hover:border-[#4E5B43] transition-colors flex-shrink-0"
            >
              {pill}
            </button>
          ))}
        </div>

        {/* Results List */}
        <div className="max-h-[55vh] overflow-y-auto p-4 sm:p-6 space-y-3">
          {filtered.length === 0 ? (
            <div className="text-center py-12 text-[#6E6C65]">
              <p className="text-sm">No furniture or décor pieces found matching "{searchTerm}"</p>
              <p className="text-xs text-[#A99A87] mt-1">Try searching for "Oak", "Linen", or "Dining"</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {filtered.map((product) => (
                <div
                  key={product.id}
                  onClick={() => {
                    onSelectProduct(product);
                    onClose();
                  }}
                  className="flex items-center gap-3.5 p-2.5 rounded-xl border border-[#E5E0D8] hover:border-[#4E5B43] hover:bg-[#F7F4EE]/50 transition-all cursor-pointer group text-left"
                >
                  <div className="w-14 h-14 rounded-lg overflow-hidden bg-[#F7F4EE] flex-shrink-0">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <span className="text-[10px] text-[#A99A87] uppercase tracking-wider block">
                      {product.category}
                    </span>
                    <h4 className="font-serif-display text-sm font-medium text-[#24241F] group-hover:text-[#26382C] truncate">
                      {product.name}
                    </h4>
                    <span className="text-xs font-semibold text-[#24241F]">
                      ${product.price.toLocaleString()}
                    </span>
                  </div>
                  <ArrowRight className="w-4 h-4 text-[#A99A87] group-hover:text-[#26382C] group-hover:translate-x-1 transition-all" />
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
