import React from 'react';
import { CATEGORIES } from '../data/products';
import { CategoryItem } from '../types';

interface CategorySectionProps {
  onSelectCategory: (categoryName: string) => void;
}

export const CategorySection: React.FC<CategorySectionProps> = ({ onSelectCategory }) => {
  return (
    <section id="shop-by-category" className="w-full py-10 sm:py-16 bg-[#F7F4EE]">
      <div className="max-w-7xl mx-auto px-4 sm:px-8">
        {/* Section Header */}
        <div className="text-center mb-8 sm:mb-12">
          <span className="text-[11px] sm:text-xs font-semibold tracking-[0.22em] text-[#4E5B43] uppercase block mb-2">
            CURATED DEPARTMENTS
          </span>
          <h2 className="font-serif-display text-3xl sm:text-4xl text-[#24241F] font-normal tracking-tight">
            Shop by Category
          </h2>
          <div className="w-12 h-0.5 bg-[#4E5B43] mx-auto mt-3.5 opacity-60" />
        </div>

        {/* Categories Grid / Mobile Scroll */}
        <div className="flex sm:grid sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-7 gap-5 sm:gap-6 overflow-x-auto pb-4 sm:pb-0 no-scrollbar snap-x">
          {CATEGORIES.map((category: CategoryItem) => (
            <div
              key={category.id}
              onClick={() => onSelectCategory(category.name)}
              className="flex flex-col items-center cursor-pointer group flex-shrink-0 w-32 sm:w-auto snap-start text-center"
            >
              {/* Softly Rounded Image Container with Warm Cream Background */}
              <div className="relative w-28 h-28 sm:w-32 sm:h-32 md:w-36 md:h-36 rounded-2xl overflow-hidden bg-[#EEE9DF] border border-[#E5E0D8] p-1.5 shadow-2xs group-hover:shadow-md group-hover:border-[#A99A87] transition-all duration-300">
                <div className="w-full h-full rounded-xl overflow-hidden bg-white/50 relative">
                  <img
                    src={category.image}
                    alt={category.name}
                    className="w-full h-full object-cover object-center transform transition-transform duration-500 ease-out group-hover:scale-106"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-[#26382C]/0 group-hover:bg-[#26382C]/5 transition-colors duration-300" />
                </div>
              </div>

              {/* Category Name & Count */}
              <h3 className="mt-3 text-xs sm:text-[13px] font-medium text-[#24241F] group-hover:text-[#26382C] transition-colors tracking-wide">
                {category.name}
              </h3>
              <span className="text-[11px] text-[#A99A87] group-hover:text-[#6E6C65] transition-colors">
                {category.itemCount} pieces
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
