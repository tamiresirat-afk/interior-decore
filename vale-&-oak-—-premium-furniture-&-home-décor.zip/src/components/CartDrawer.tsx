import React, { useState } from 'react';
import { X, Plus, Minus, Trash2, ArrowRight, ShieldCheck, Truck, Sparkles } from 'lucide-react';
import { CartItem } from '../types';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (productId: string, quantity: number) => void;
  onRemoveItem: (productId: string) => void;
  onOpenCheckout: () => void;
  onShopClick: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onOpenCheckout,
  onShopClick
}) => {
  const [promoCode, setPromoCode] = useState('');
  const [discountPercent, setDiscountPercent] = useState(0);
  const [promoMessage, setPromoMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const rawSubtotal = items.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const discountAmount = Math.round(rawSubtotal * (discountPercent / 100));
  const subtotal = rawSubtotal - discountAmount;

  // Free shipping threshold at $1,500
  const freeShippingThreshold = 1500;
  const progressPercent = Math.min(100, Math.round((subtotal / freeShippingThreshold) * 100));
  const amountNeeded = Math.max(0, freeShippingThreshold - subtotal);

  const handleApplyPromo = (e: React.FormEvent) => {
    e.preventDefault();
    const code = promoCode.trim().toUpperCase();
    if (code === 'WELCOME10' || code === 'AUTUMN10') {
      setDiscountPercent(10);
      setPromoMessage('10% off applied to your order.');
    } else if (code === 'VALE20') {
      setDiscountPercent(20);
      setPromoMessage('20% architectural edit discount applied.');
    } else {
      setPromoMessage('Code not recognized. Try WELCOME10');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/40 backdrop-blur-xs transition-opacity duration-300"
        onClick={onClose}
      />

      {/* Drawer Panel */}
      <div className="relative w-full max-w-md bg-white h-full shadow-2xl flex flex-col z-10 animate-in slide-in-from-right duration-300">
        {/* Header */}
        <div className="p-5 border-b border-[#E5E0D8] flex items-center justify-between bg-[#F7F4EE]">
          <div className="flex items-center gap-2">
            <h2 className="font-serif-display text-xl font-semibold text-[#24241F]">
              Your Shopping Bag
            </h2>
            <span className="text-xs text-[#6E6C65] font-medium">
              ({items.reduce((acc, i) => acc + i.quantity, 0)} items)
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#6E6C65] hover:text-[#24241F] rounded-full hover:bg-white transition-colors"
            aria-label="Close shopping bag"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Free Shipping Progress Meter */}
        <div className="bg-[#FDFBF7] px-5 py-3 border-b border-[#E5E0D8] text-xs">
          <div className="flex items-center justify-between text-[#24241F] mb-1.5">
            <div className="flex items-center gap-1.5">
              <Truck className="w-3.5 h-3.5 text-[#4E5B43]" />
              <span className="font-medium">
                {amountNeeded === 0 ? (
                  <strong className="text-[#4E5B43]">Complimentary White-Glove Delivery Unlocked!</strong>
                ) : (
                  <>Add <strong>${amountNeeded.toLocaleString()}</strong> more for free white-glove delivery</>
                )}
              </span>
            </div>
            <span className="font-semibold text-[11px] text-[#4E5B43]">{progressPercent}%</span>
          </div>
          <div className="w-full bg-[#E5E0D8] h-1.5 rounded-full overflow-hidden">
            <div 
              className="bg-[#4E5B43] h-full transition-all duration-500 rounded-full"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>

        {/* Cart Item List */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {items.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-4">
              <div className="w-16 h-16 rounded-full bg-[#F7F4EE] border border-[#E5E0D8] flex items-center justify-center text-[#A99A87]">
                <Sparkles className="w-8 h-8 stroke-1" />
              </div>
              <div className="space-y-1">
                <h3 className="font-serif-display text-xl text-[#24241F]">Your bag is currently empty</h3>
                <p className="text-xs text-[#6E6C65] max-w-xs">
                  Discover our considered seating, architectural tables, and handcrafted ceramics.
                </p>
              </div>
              <button
                onClick={() => {
                  onClose();
                  onShopClick();
                }}
                className="bg-[#26382C] text-[#F7F4EE] px-6 py-2.5 rounded-lg text-xs font-semibold tracking-wider uppercase hover:bg-[#19271E] transition-colors"
              >
                Start Exploring
              </button>
            </div>
          ) : (
            items.map((item) => (
              <div 
                key={item.product.id}
                className="flex gap-4 pb-4 border-b border-[#E5E0D8]/70 text-left"
              >
                {/* Thumbnail */}
                <div className="w-20 h-20 rounded-lg overflow-hidden bg-[#F7F4EE] border border-[#E5E0D8] flex-shrink-0">
                  <img
                    src={item.product.image}
                    alt={item.product.name}
                    className="w-full h-full object-cover"
                  />
                </div>

                {/* Info */}
                <div className="flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex justify-between items-start">
                      <h4 className="font-serif-display text-base font-medium text-[#24241F] leading-tight">
                        {item.product.name}
                      </h4>
                      <button
                        onClick={() => onRemoveItem(item.product.id)}
                        className="text-[#A99A87] hover:text-rose-600 transition-colors p-1 -mr-1"
                        aria-label="Remove item"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    {item.selectedFinish && (
                      <p className="text-[11px] text-[#6E6C65] mt-0.5">
                        Finish: {item.selectedFinish}
                      </p>
                    )}
                  </div>

                  <div className="flex items-center justify-between mt-2">
                    {/* Quantity controls */}
                    <div className="flex items-center border border-[#E5E0D8] rounded-md bg-[#F7F4EE]">
                      <button
                        onClick={() => onUpdateQuantity(item.product.id, Math.max(1, item.quantity - 1))}
                        className="p-1 px-2 text-[#6E6C65] hover:text-[#24241F]"
                        aria-label="Decrease quantity"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="px-2 text-xs font-semibold text-[#24241F]">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() => onUpdateQuantity(item.product.id, item.quantity + 1)}
                        className="p-1 px-2 text-[#6E6C65] hover:text-[#24241F]"
                        aria-label="Increase quantity"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>

                    <div className="text-right">
                      <span className="text-sm font-semibold text-[#24241F]">
                        ${(item.product.price * item.quantity).toLocaleString()}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer / Checkout */}
        {items.length > 0 && (
          <div className="p-5 border-t border-[#E5E0D8] bg-[#FDFBF7] space-y-3">
            {/* Promo Code Accordion */}
            <form onSubmit={handleApplyPromo} className="flex gap-2">
              <input
                type="text"
                value={promoCode}
                onChange={(e) => setPromoCode(e.target.value)}
                placeholder="Promo code (e.g. WELCOME10)"
                className="flex-1 bg-white border border-[#E5E0D8] rounded-md px-3 py-1.5 text-xs text-[#24241F] uppercase placeholder:normal-case placeholder:text-[#A99A87] focus:outline-none focus:border-[#4E5B43]"
              />
              <button
                type="submit"
                className="px-3 py-1.5 bg-[#EEE9DF] hover:bg-[#D9CDBD] text-[#24241F] text-xs font-semibold rounded-md transition-colors"
              >
                Apply
              </button>
            </form>
            {promoMessage && (
              <p className={`text-[11px] text-left ${discountPercent > 0 ? 'text-[#4E5B43] font-medium' : 'text-amber-700'}`}>
                {promoMessage}
              </p>
            )}

            {/* Calculations */}
            <div className="space-y-1.5 text-xs pt-1 border-t border-[#E5E0D8]/60">
              <div className="flex justify-between text-[#6E6C65]">
                <span>Items Subtotal</span>
                <span>${rawSubtotal.toLocaleString()}</span>
              </div>
              {discountPercent > 0 && (
                <div className="flex justify-between text-[#4E5B43] font-medium">
                  <span>Special Discount ({discountPercent}%)</span>
                  <span>-${discountAmount.toLocaleString()}</span>
                </div>
              )}
              <div className="flex justify-between text-[#6E6C65]">
                <span>White-Glove In-Home Delivery</span>
                <span>{amountNeeded === 0 ? 'COMPLIMENTARY' : '$150'}</span>
              </div>
              <div className="flex justify-between text-base font-semibold text-[#24241F] pt-2 border-t border-[#E5E0D8]">
                <span>Estimated Total</span>
                <span>${(subtotal + (amountNeeded === 0 ? 0 : 150)).toLocaleString()}</span>
              </div>
            </div>

            {/* Checkout Button */}
            <button
              id="cart-checkout-button"
              onClick={onOpenCheckout}
              className="w-full bg-[#26382C] hover:bg-[#19271E] text-[#F7F4EE] py-3.5 rounded-lg text-xs font-semibold tracking-wider uppercase transition-all duration-200 flex items-center justify-center gap-2 shadow-md"
            >
              <span>Proceed to Checkout</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            {/* Security Assurance */}
            <div className="flex items-center justify-center gap-1.5 text-[11px] text-[#A99A87] pt-1">
              <ShieldCheck className="w-3.5 h-3.5 text-[#4E5B43]" />
              <span>256-bit encrypted • 30-day in-home returns</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
