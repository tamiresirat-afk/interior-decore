import React, { useState, useEffect } from 'react';
import { 
  Search, 
  User, 
  Heart, 
  ShoppingBag, 
  Menu, 
  X, 
  ChevronDown, 
  Truck, 
  RotateCcw, 
  ShieldCheck, 
  Sparkles,
  ArrowRight
} from 'lucide-react';
import { ActiveView } from '../types';

interface HeaderProps {
  activeView: ActiveView;
  setActiveView: (view: ActiveView) => void;
  cartCount: number;
  wishlistCount: number;
  onOpenCart: () => void;
  onOpenWishlist: () => void;
  onOpenSearch: () => void;
  onOpenAccount: () => void;
  onSelectCategory?: (categoryName: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeView,
  setActiveView,
  cartCount,
  wishlistCount,
  onOpenCart,
  onOpenWishlist,
  onOpenSearch,
  onOpenAccount,
  onSelectCategory
}) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 40) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNavClick = (view: ActiveView, categoryFilter?: string) => {
    setActiveView(view);
    setActiveDropdown(null);
    setMobileMenuOpen(false);
    if (categoryFilter && onSelectCategory) {
      onSelectCategory(categoryFilter);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <>
      {/* 1. TOP PROMOTIONAL BANNER */}
      <div 
        id="top-promo-banner" 
        className="w-full bg-[#26382C] text-[#F7F4EE] px-4 py-2.5 sm:py-2 flex items-center justify-between text-xs tracking-wider transition-colors"
      >
        <div className="hidden lg:block w-32" /> {/* Balancing spacer */}

        <div className="flex-1 text-center font-medium text-[11px] sm:text-[13px] tracking-widest uppercase">
          <span>DESIGNED FOR BEAUTIFUL LIVING — </span>
          <span className="text-[#D9CDBD] font-semibold underline decoration-[#A7AD96]/60 underline-offset-4">
            DISCOVER THE AUTUMN COLLECTION
          </span>
        </div>

        <div className="flex items-center justify-end">
          <button
            id="banner-cta-button"
            onClick={() => handleNavClick('shop')}
            className="inline-flex items-center gap-1 bg-[#F7F4EE] hover:bg-[#EEE9DF] text-[#26382C] font-semibold px-3 py-1 rounded-full text-[11px] sm:text-xs transition-all duration-200 transform hover:scale-[1.02] active:scale-95 shadow-sm whitespace-nowrap"
          >
            <span>SHOP NEW ARRIVALS</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* 2. UTILITY BENEFITS BAR */}
      <div 
        id="utility-benefits-bar" 
        className="w-full bg-[#FDFBF7] border-b border-[#E5E0D8] text-[#6E6C65] text-xs py-2 px-4 sm:px-8"
      >
        <div className="max-w-7xl mx-auto flex items-center justify-between overflow-x-auto no-scrollbar gap-6 sm:gap-4">
          <div className="flex items-center gap-2 flex-shrink-0">
            <Truck className="w-3.5 h-3.5 text-[#4E5B43]" />
            <span className="text-[11px] sm:text-xs font-normal">Complimentary delivery over $1,500</span>
          </div>
          <div className="flex items-center gap-2 flex-shrink-0">
            <RotateCcw className="w-3.5 h-3.5 text-[#4E5B43]" />
            <span className="text-[11px] sm:text-xs font-normal">30-day in-home trial & easy returns</span>
          </div>
          <div className="flex items-center gap-2 flex-shrink-0">
            <ShieldCheck className="w-3.5 h-3.5 text-[#4E5B43]" />
            <span className="text-[11px] sm:text-xs font-normal">256-bit secure encrypted checkout</span>
          </div>
          <div className="flex items-center gap-2 flex-shrink-0">
            <Sparkles className="w-3.5 h-3.5 text-[#4E5B43]" />
            <span className="text-[11px] sm:text-xs font-normal">Complimentary interior design guidance</span>
          </div>
        </div>
      </div>

      {/* 3. MAIN HEADER / NAVIGATION */}
      <header
        id="main-site-header"
        className={`w-full sticky top-0 z-40 bg-white/95 backdrop-blur-md transition-all duration-200 border-b ${
          isScrolled 
            ? 'py-3 shadow-xs border-[#E5E0D8]' 
            : 'py-4.5 sm:py-5 border-[#E5E0D8]/60'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-8 flex items-center justify-between">
          {/* Mobile Menu Trigger & Left Branding */}
          <div className="flex items-center gap-3 lg:gap-0">
            <button
              id="mobile-menu-trigger"
              onClick={() => setMobileMenuOpen(true)}
              className="lg:hidden p-1.5 -ml-1.5 text-[#24241F] hover:text-[#4E5B43] rounded-md transition-colors"
              aria-label="Open mobile navigation"
            >
              <Menu className="w-6 h-6" />
            </button>

            {/* Brand Logo */}
            <div 
              onClick={() => handleNavClick('home')}
              className="cursor-pointer group flex items-center gap-2.5"
            >
              {/* Architectural Arch & Pillar Icon */}
              <div className="w-8 h-8 rounded-sm bg-[#26382C] text-[#F7F4EE] flex items-center justify-center transition-transform group-hover:scale-105 duration-200">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" className="w-5 h-5">
                  <path d="M4 21V10a8 8 0 0 1 16 0v11" />
                  <path d="M4 21h16" />
                  <path d="M9 21v-7a3 3 0 0 1 6 0v7" />
                </svg>
              </div>

              <div>
                <span className="font-serif-display text-2xl sm:text-2xl tracking-[0.14em] font-semibold text-[#24241F] group-hover:text-[#26382C] transition-colors">
                  VALE & OAK
                </span>
                <span className="hidden sm:block text-[9px] uppercase tracking-[0.24em] text-[#6E6C65] -mt-1 font-medium">
                  Atelier of Living
                </span>
              </div>
            </div>
          </div>

          {/* Desktop Center Navigation */}
          <nav className="hidden lg:flex items-center gap-6 xl:gap-8 text-[13px] font-medium tracking-wider text-[#24241F]">
            <button
              onClick={() => handleNavClick('home')}
              className={`py-2 transition-colors hover:text-[#4E5B43] relative ${
                activeView === 'home' ? 'text-[#26382C] font-semibold' : 'text-[#6E6C65]'
              }`}
            >
              HOME
              {activeView === 'home' && (
                <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#26382C]" />
              )}
            </button>

            <button
              onClick={() => handleNavClick('shop')}
              className={`py-2 transition-colors hover:text-[#4E5B43] relative ${
                activeView === 'shop' ? 'text-[#26382C] font-semibold' : 'text-[#6E6C65]'
              }`}
            >
              SHOP
              {activeView === 'shop' && (
                <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#26382C]" />
              )}
            </button>

            {/* Living with Dropdown */}
            <div 
              className="relative group"
              onMouseEnter={() => setActiveDropdown('living')}
              onMouseLeave={() => setActiveDropdown(null)}
            >
              <button
                onClick={() => handleNavClick('shop', 'Living Room')}
                className="py-2 flex items-center gap-1 text-[#6E6C65] hover:text-[#4E5B43] transition-colors"
              >
                <span>LIVING</span>
                <ChevronDown className="w-3 h-3 text-[#A99A87] group-hover:rotate-180 transition-transform duration-200" />
              </button>

              {activeDropdown === 'living' && (
                <div className="absolute top-full left-1/2 -translate-x-1/2 w-72 bg-white rounded-lg shadow-xl border border-[#E5E0D8] p-4 animate-in fade-in slide-in-from-top-2 duration-150 z-50">
                  <div className="text-[10px] uppercase font-bold text-[#A99A87] tracking-wider mb-2">Living Collection</div>
                  <ul className="space-y-1.5 text-xs text-[#24241F]">
                    <li>
                      <button onClick={() => handleNavClick('shop', 'Living Room')} className="w-full text-left py-1 hover:text-[#4E5B43] hover:translate-x-1 transition-all">
                        All Living Room
                      </button>
                    </li>
                    <li>
                      <button onClick={() => handleNavClick('shop', 'Living Room')} className="w-full text-left py-1 hover:text-[#4E5B43] hover:translate-x-1 transition-all text-[#6E6C65]">
                        Linen & Velvet Sofas
                      </button>
                    </li>
                    <li>
                      <button onClick={() => handleNavClick('shop', 'Living Room')} className="w-full text-left py-1 hover:text-[#4E5B43] hover:translate-x-1 transition-all text-[#6E6C65]">
                        Sculptural Lounge Chairs
                      </button>
                    </li>
                    <li>
                      <button onClick={() => handleNavClick('shop', 'Living Room')} className="w-full text-left py-1 hover:text-[#4E5B43] hover:translate-x-1 transition-all text-[#6E6C65]">
                        Solid Oak Coffee Tables
                      </button>
                    </li>
                  </ul>
                  <div className="mt-3 pt-3 border-t border-[#E5E0D8]/60 bg-[#F7F4EE]/50 p-2 rounded">
                    <span className="text-[10px] text-[#26382C] font-semibold block">Featured: Arden Lounge Chair</span>
                    <span className="text-[10px] text-[#6E6C65]">Hand-joined European White Oak</span>
                  </div>
                </div>
              )}
            </div>

            {/* Bedroom */}
            <button
              onClick={() => handleNavClick('shop', 'Bedroom')}
              className="py-2 text-[#6E6C65] hover:text-[#4E5B43] transition-colors"
            >
              BEDROOM
            </button>

            {/* Dining */}
            <button
              onClick={() => handleNavClick('shop', 'Dining')}
              className="py-2 text-[#6E6C65] hover:text-[#4E5B43] transition-colors"
            >
              DINING
            </button>

            {/* Office */}
            <button
              onClick={() => handleNavClick('shop', 'Home Office')}
              className="py-2 text-[#6E6C65] hover:text-[#4E5B43] transition-colors"
            >
              OFFICE
            </button>

            {/* Décor */}
            <button
              onClick={() => handleNavClick('shop', 'Décor & Accents')}
              className="py-2 text-[#6E6C65] hover:text-[#4E5B43] transition-colors"
            >
              DÉCOR
            </button>

            {/* Sale */}
            <button
              onClick={() => handleNavClick('shop')}
              className="py-2 text-[#745943] hover:text-[#26382C] font-semibold transition-colors"
            >
              SALE
            </button>

            {/* Journal */}
            <button
              onClick={() => handleNavClick('journal')}
              className={`py-2 transition-colors hover:text-[#4E5B43] ${
                activeView === 'journal' ? 'text-[#26382C] font-semibold' : 'text-[#6E6C65]'
              }`}
            >
              JOURNAL
            </button>

            {/* About */}
            <button
              onClick={() => handleNavClick('about')}
              className={`py-2 transition-colors hover:text-[#4E5B43] ${
                activeView === 'about' ? 'text-[#26382C] font-semibold' : 'text-[#6E6C65]'
              }`}
            >
              ABOUT
            </button>
          </nav>

          {/* Right Action Icons */}
          <div className="flex items-center gap-1 sm:gap-2 text-[#24241F]">
            {/* Search */}
            <button
              id="header-search-button"
              onClick={onOpenSearch}
              className="p-2 hover:bg-[#F7F4EE] rounded-full transition-colors text-[#24241F] hover:text-[#4E5B43]"
              aria-label="Search furniture catalog"
            >
              <Search className="w-5 h-5 stroke-[1.75]" />
            </button>

            {/* Account */}
            <button
              id="header-account-button"
              onClick={onOpenAccount}
              className="p-2 hover:bg-[#F7F4EE] rounded-full transition-colors text-[#24241F] hover:text-[#4E5B43] hidden sm:flex"
              aria-label="Account and trade membership"
            >
              <User className="w-5 h-5 stroke-[1.75]" />
            </button>

            {/* Wishlist */}
            <button
              id="header-wishlist-button"
              onClick={onOpenWishlist}
              className="p-2 hover:bg-[#F7F4EE] rounded-full transition-colors text-[#24241F] hover:text-[#4E5B43] relative"
              aria-label="View wishlist"
            >
              <Heart className="w-5 h-5 stroke-[1.75]" />
              {wishlistCount > 0 && (
                <span className="absolute top-1 right-1 bg-[#4E5B43] text-white text-[10px] w-4 h-4 rounded-full flex items-center justify-center font-bold animate-in zoom-in duration-150">
                  {wishlistCount}
                </span>
              )}
            </button>

            {/* Cart */}
            <button
              id="header-cart-button"
              onClick={onOpenCart}
              className="p-2 hover:bg-[#F7F4EE] rounded-full transition-colors text-[#24241F] hover:text-[#4E5B43] relative"
              aria-label="View shopping bag"
            >
              <ShoppingBag className="w-5 h-5 stroke-[1.75]" />
              {cartCount > 0 && (
                <span className="absolute top-1 right-1 bg-[#26382C] text-[#F7F4EE] text-[10px] w-4 h-4 rounded-full flex items-center justify-center font-bold animate-in zoom-in duration-150">
                  {cartCount}
                </span>
              )}
            </button>
          </div>
        </div>
      </header>

      {/* MOBILE DRAWER */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div 
            className="fixed inset-0 bg-black/40 backdrop-blur-xs transition-opacity"
            onClick={() => setMobileMenuOpen(false)}
          />

          <div className="relative w-4/5 max-w-sm bg-[#F7F4EE] h-full shadow-2xl flex flex-col z-10 border-r border-[#E5E0D8] animate-in slide-in-from-left duration-250">
            {/* Drawer Header */}
            <div className="p-5 border-b border-[#E5E0D8] flex items-center justify-between bg-white">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-sm bg-[#26382C] text-[#F7F4EE] flex items-center justify-center">
                  <span className="font-serif-display font-bold text-xs">V</span>
                </div>
                <span className="font-serif-display font-semibold text-lg tracking-wider text-[#24241F]">
                  VALE & OAK
                </span>
              </div>
              <button
                onClick={() => setMobileMenuOpen(false)}
                className="p-1.5 text-[#6E6C65] hover:text-[#24241F]"
                aria-label="Close navigation menu"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Drawer Navigation Links */}
            <div className="flex-1 overflow-y-auto p-5 space-y-4 text-sm font-medium">
              <div className="text-[11px] uppercase tracking-widest text-[#A99A87] font-semibold mb-2">
                Explore Departments
              </div>

              <div className="space-y-1">
                <button
                  onClick={() => handleNavClick('home')}
                  className="w-full text-left py-2 px-3 rounded-md hover:bg-white text-[#24241F]"
                >
                  Home
                </button>
                <button
                  onClick={() => handleNavClick('shop')}
                  className="w-full text-left py-2 px-3 rounded-md hover:bg-white text-[#24241F] font-semibold"
                >
                  All Furniture & Décor
                </button>
                <button
                  onClick={() => handleNavClick('shop', 'Living Room')}
                  className="w-full text-left py-2 px-3 rounded-md hover:bg-white text-[#6E6C65]"
                >
                  Living Room
                </button>
                <button
                  onClick={() => handleNavClick('shop', 'Bedroom')}
                  className="w-full text-left py-2 px-3 rounded-md hover:bg-white text-[#6E6C65]"
                >
                  Bedroom
                </button>
                <button
                  onClick={() => handleNavClick('shop', 'Dining')}
                  className="w-full text-left py-2 px-3 rounded-md hover:bg-white text-[#6E6C65]"
                >
                  Dining
                </button>
                <button
                  onClick={() => handleNavClick('shop', 'Home Office')}
                  className="w-full text-left py-2 px-3 rounded-md hover:bg-white text-[#6E6C65]"
                >
                  Home Office
                </button>
                <button
                  onClick={() => handleNavClick('shop', 'Lighting')}
                  className="w-full text-left py-2 px-3 rounded-md hover:bg-white text-[#6E6C65]"
                >
                  Lighting
                </button>
                <button
                  onClick={() => handleNavClick('shop', 'Décor & Accents')}
                  className="w-full text-left py-2 px-3 rounded-md hover:bg-white text-[#6E6C65]"
                >
                  Décor & Objects
                </button>
              </div>

              <div className="pt-4 border-t border-[#E5E0D8] space-y-2">
                <button
                  onClick={() => handleNavClick('journal')}
                  className="w-full text-left py-1.5 px-3 text-[#24241F]"
                >
                  The Journal
                </button>
                <button
                  onClick={() => handleNavClick('about')}
                  className="w-full text-left py-1.5 px-3 text-[#24241F]"
                >
                  Our Craft & Heritage
                </button>
              </div>
            </div>

            {/* Drawer Footer */}
            <div className="p-5 border-t border-[#E5E0D8] bg-white text-xs space-y-3">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenAccount();
                }}
                className="w-full py-2.5 px-4 bg-[#F7F4EE] border border-[#E5E0D8] rounded-md font-medium text-[#24241F] flex items-center justify-center gap-2"
              >
                <User className="w-4 h-4 text-[#4E5B43]" />
                <span>Trade & Customer Sign In</span>
              </button>
              <div className="text-center text-[#6E6C65] text-[11px]">
                Complimentary consultations: concierge@valeandoak.com
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
