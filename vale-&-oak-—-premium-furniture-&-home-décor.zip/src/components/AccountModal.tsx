import React, { useState } from 'react';
import { X, User, Package, Heart, Sparkles, ShieldCheck, Mail, MapPin } from 'lucide-react';

interface AccountModalProps {
  isOpen: boolean;
  onClose: () => void;
  wishlistCount: number;
  onOpenWishlist: () => void;
}

export const AccountModal: React.FC<AccountModalProps> = ({
  isOpen,
  onClose,
  wishlistCount,
  onOpenWishlist
}) => {
  const [tab, setTab] = useState<'profile' | 'trade' | 'orders'>('profile');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
      <div 
        className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      <div className="relative w-full max-w-xl bg-white rounded-2xl shadow-2xl border border-[#E5E0D8] overflow-hidden z-10 my-auto text-left">
        {/* Header */}
        <div className="p-5 border-b border-[#E5E0D8] flex items-center justify-between bg-[#F7F4EE]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-[#26382C] text-[#F7F4EE] flex items-center justify-center">
              <User className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-serif-display text-lg font-semibold text-[#24241F]">
                Vale & Oak Concierge
              </h2>
              <span className="text-[11px] text-[#4E5B43] font-medium block">
                Trade & Client Atelier Member
              </span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#6E6C65] hover:text-[#24241F] rounded-full hover:bg-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-[#E5E0D8] bg-[#FDFBF7] text-xs font-semibold">
          <button
            onClick={() => setTab('profile')}
            className={`flex-1 py-3 text-center border-b-2 transition-colors ${
              tab === 'profile'
                ? 'border-[#26382C] text-[#26382C]'
                : 'border-transparent text-[#6E6C65] hover:text-[#24241F]'
            }`}
          >
            Client Profile
          </button>
          <button
            onClick={() => setTab('trade')}
            className={`flex-1 py-3 text-center border-b-2 transition-colors flex items-center justify-center gap-1.5 ${
              tab === 'trade'
                ? 'border-[#26382C] text-[#26382C]'
                : 'border-transparent text-[#6E6C65] hover:text-[#24241F]'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-[#C49E68]" />
            <span>Trade & Architects</span>
          </button>
          <button
            onClick={() => setTab('orders')}
            className={`flex-1 py-3 text-center border-b-2 transition-colors ${
              tab === 'orders'
                ? 'border-[#26382C] text-[#26382C]'
                : 'border-transparent text-[#6E6C65] hover:text-[#24241F]'
            }`}
          >
            Past Deliveries
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          {tab === 'profile' && (
            <div className="space-y-4 text-xs">
              <div className="bg-[#F7F4EE] p-4 rounded-xl border border-[#E5E0D8] flex items-center justify-between">
                <div>
                  <span className="font-semibold text-sm text-[#24241F] block">Elena Rostova</span>
                  <span className="text-[#6E6C65]">elena.rostova@example.com</span>
                  <span className="text-[11px] text-[#4E5B43] block mt-1">Tier: Architectural Collector</span>
                </div>
                <button
                  onClick={() => {
                    onClose();
                    onOpenWishlist();
                  }}
                  className="px-3 py-1.5 bg-white border border-[#E5E0D8] rounded-md text-[11px] font-semibold text-[#24241F] hover:border-[#4E5B43] flex items-center gap-1.5"
                >
                  <Heart className="w-3.5 h-3.5 text-[#4E5B43]" />
                  <span>Wishlist ({wishlistCount})</span>
                </button>
              </div>

              <div className="space-y-2 text-[#6E6C65]">
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-[#4E5B43]" />
                  <span>Default Address: 742 Evergreen Terrace, Apt 4B, New York, NY 10012</span>
                </div>
                <div className="flex items-center gap-2">
                  <Mail className="w-4 h-4 text-[#4E5B43]" />
                  <span>Concierge Representative: James Vance (Assigned Interior Advisor)</span>
                </div>
              </div>

              <div className="pt-3 border-t border-[#E5E0D8] flex justify-between items-center text-[11px] text-[#A99A87]">
                <span>Member since October 2024</span>
                <span className="text-[#4E5B43] font-medium">Complimentary Fabric Swatch Kit Active</span>
              </div>
            </div>
          )}

          {tab === 'trade' && (
            <div className="space-y-4 text-xs text-left">
              <div className="border border-[#C49E68]/40 bg-[#FDFBF7] p-4 rounded-xl">
                <div className="flex items-center gap-2 text-[#24241F] font-serif-display text-base font-semibold mb-1">
                  <Sparkles className="w-4 h-4 text-[#C49E68]" />
                  <span>The Vale & Oak Trade Program</span>
                </div>
                <p className="text-[#6E6C65] leading-relaxed">
                  Tailored exclusively for licensed interior designers, architects, and hospitality developers. Receive 20% tier discounts, custom timber lengths, dedicated finish customization, and reserved production queues.
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3 text-[11px]">
                <div className="p-3 bg-[#F7F4EE] rounded-lg border border-[#E5E0D8]">
                  <strong className="block text-[#24241F] mb-0.5">Custom Sizing</strong>
                  <span className="text-[#6E6C65]">Bespoke dining table lengths up to 12 feet.</span>
                </div>
                <div className="p-3 bg-[#F7F4EE] rounded-lg border border-[#E5E0D8]">
                  <strong className="block text-[#24241F] mb-0.5">Complimentary Swatches</strong>
                  <span className="text-[#6E6C65]">Boxed 24-piece linen, timber & stone kit.</span>
                </div>
              </div>

              <button
                onClick={() => alert('Trade invitation initiated. An architectural specialist will contact your email.')}
                className="w-full py-3 bg-[#26382C] text-white rounded-lg text-xs font-semibold uppercase tracking-wider hover:bg-[#19271E] transition-colors"
              >
                Request Trade Accreditation
              </button>
            </div>
          )}

          {tab === 'orders' && (
            <div className="space-y-3 text-xs">
              <div className="p-3.5 rounded-lg border border-[#E5E0D8] bg-[#F7F4EE] flex justify-between items-center">
                <div>
                  <span className="font-mono text-[11px] text-[#A99A87] block">ORDER #VO-948120</span>
                  <span className="font-semibold text-sm text-[#24241F]">Arden Lounge Chair (Smoked Oak)</span>
                  <span className="text-[11px] text-[#4E5B43] block mt-0.5">Delivered & Assembled • White Glove</span>
                </div>
                <span className="font-bold text-[#24241F]">$1,240</span>
              </div>

              <div className="p-3.5 rounded-lg border border-[#E5E0D8] bg-[#F7F4EE] flex justify-between items-center">
                <div>
                  <span className="font-mono text-[11px] text-[#A99A87] block">ORDER #VO-831092</span>
                  <span className="font-semibold text-sm text-[#24241F]">Solis Ceramic Table Lamp (Chalk Matte)</span>
                  <span className="text-[11px] text-[#4E5B43] block mt-0.5">Delivered via Express Courier</span>
                </div>
                <span className="font-bold text-[#24241F]">$340</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
