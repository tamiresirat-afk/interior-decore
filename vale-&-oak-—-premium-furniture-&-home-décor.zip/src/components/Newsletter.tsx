import React, { useState } from 'react';
import { Mail, CheckCircle2, ArrowRight, AlertCircle } from 'lucide-react';

export const Newsletter: React.FC = () => {
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    // Strict email regex validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email.trim()) {
      setStatus('error');
      setErrorMessage('Please enter your email address.');
      return;
    }

    if (!emailRegex.test(email.trim())) {
      setStatus('error');
      setErrorMessage('Please enter a valid email address (e.g. name@domain.com).');
      return;
    }

    setStatus('loading');
    setTimeout(() => {
      setStatus('success');
      // Save locally to represent community newsletter subscription
      try {
        const saved = JSON.parse(localStorage.getItem('vale_oak_newsletter_subscribers') || '[]');
        if (!saved.includes(email.trim())) {
          saved.push(email.trim());
          localStorage.setItem('vale_oak_newsletter_subscribers', JSON.stringify(saved));
        }
      } catch {
        // Safe fallback
      }
    }, 600);
  };

  return (
    <section id="newsletter-section" className="w-full py-10 sm:py-16 bg-[#F7F4EE]">
      <div className="max-w-7xl mx-auto px-4 sm:px-8">
        <div className="bg-[#26382C] text-[#F7F4EE] rounded-2xl sm:rounded-3xl p-8 sm:p-12 lg:p-16 border border-[#4E5B43]/50 shadow-md">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
            {/* Left Column: Icon & Copy (7 cols) */}
            <div className="lg:col-span-7 text-left">
              <div className="w-11 h-11 rounded-xl bg-[#4E5B43]/50 border border-[#A7AD96]/30 flex items-center justify-center text-[#D9CDBD] mb-4">
                <Mail className="w-5 h-5 stroke-[1.75]" />
              </div>
              <h2 className="font-serif-display text-3xl sm:text-4xl font-normal tracking-tight text-white mb-3">
                Join Our Design Community
              </h2>
              <p className="text-[#D9CDBD] text-sm sm:text-base leading-relaxed max-w-lg font-normal">
                New collections, styling ideas, architectural journal essays, and private seasonal invitations, delivered thoughtfully.
              </p>
            </div>

            {/* Right Column: Form (5 cols) */}
            <div className="lg:col-span-5">
              {status === 'success' ? (
                <div className="bg-[#4E5B43]/40 border border-[#A7AD96]/40 p-6 rounded-xl text-left animate-in fade-in duration-300">
                  <div className="flex items-center gap-2.5 text-[#F7F4EE] font-semibold text-sm mb-1.5">
                    <CheckCircle2 className="w-5 h-5 text-[#A7AD96]" />
                    <span>Welcome to Vale & Oak</span>
                  </div>
                  <p className="text-xs text-[#D9CDBD] leading-relaxed">
                    Thank you for joining. We have noted <strong className="text-white">{email}</strong>. Look out for your welcome guide and initial architectural curation soon.
                  </p>
                  <button
                    onClick={() => {
                      setStatus('idle');
                      setEmail('');
                    }}
                    className="mt-4 text-[11px] uppercase tracking-wider text-[#A7AD96] hover:text-white underline underline-offset-4"
                  >
                    Subscribe another email
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-3">
                  <div className="flex flex-col sm:flex-row gap-2.5">
                    <div className="relative flex-1">
                      <input
                        type="email"
                        id="newsletter-email-input"
                        value={email}
                        onChange={(e) => {
                          setEmail(e.target.value);
                          if (status === 'error') setStatus('idle');
                        }}
                        placeholder="Enter your email address"
                        className="w-full bg-[#1C2B21] border border-[#4E5B43] rounded-lg px-4 py-3.5 text-sm text-[#F7F4EE] placeholder-[#A99A87] focus:outline-none focus:border-[#D9CDBD] transition-colors"
                        disabled={status === 'loading'}
                        aria-label="Email address for newsletter"
                      />
                    </div>
                    <button
                      type="submit"
                      id="newsletter-submit-button"
                      disabled={status === 'loading'}
                      className="bg-[#F7F4EE] hover:bg-white text-[#26382C] px-6 py-3.5 rounded-lg text-xs font-semibold tracking-wider uppercase transition-all duration-200 transform hover:scale-[1.02] active:scale-95 disabled:opacity-60 whitespace-nowrap flex items-center justify-center gap-2 shadow-sm"
                    >
                      {status === 'loading' ? (
                        <span>Subscribing...</span>
                      ) : (
                        <>
                          <span>Subscribe</span>
                          <ArrowRight className="w-3.5 h-3.5" />
                        </>
                      )}
                    </button>
                  </div>

                  {status === 'error' && (
                    <div className="flex items-center gap-2 text-rose-300 text-xs text-left animate-in fade-in duration-150">
                      <AlertCircle className="w-3.5 h-3.5 flex-shrink-0" />
                      <span>{errorMessage}</span>
                    </div>
                  )}

                  <p className="text-[11px] text-[#A7AD96] text-left">
                    We respect your privacy. Unsubscribe anytime with a single click.
                  </p>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
