import React from 'react';
import { ArrowLeft, ArrowRight, Clock } from 'lucide-react';

interface JournalViewProps {
  onBackToHome: () => void;
  onShopClick: () => void;
}

export const JournalView: React.FC<JournalViewProps> = ({ onBackToHome, onShopClick }) => {
  const articles = [
    {
      id: 'journal-1',
      title: 'The Architecture of Serenity: Designing with Unfinished Timber & Natural Light',
      category: 'Interior Architecture',
      readTime: '6 min read',
      date: 'September 2024',
      image: 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1200&q=85',
      excerpt: 'How generous negative space, hand-rubbed wax oil seals, and low-profile seating anchor contemporary living rooms in natural calm.'
    },
    {
      id: 'journal-2',
      title: 'Caring for Solid European Oak: A Guide to Natural Patina & Living Finishes',
      category: 'Craft & Care',
      readTime: '4 min read',
      date: 'August 2024',
      image: 'https://images.unsplash.com/photo-1615066390971-03e4e1c36ddf?auto=format&fit=crop&w=1200&q=85',
      excerpt: 'Unlike synthetic polyurethane varnishes, organic beeswax and botanical oils permit timber to breathe, evolving a richer golden character each decade.'
    },
    {
      id: 'journal-3',
      title: 'The Tactile Room: Why Belgian Flax & Bouclé Deepen Acoustic Comfort',
      category: 'Material Studies',
      readTime: '5 min read',
      date: 'July 2024',
      image: 'https://images.unsplash.com/photo-1493663284031-b7e3aefcae8e?auto=format&fit=crop&w=1200&q=85',
      excerpt: 'Pure flax fiber absorbs reverberant sound while maintaining temperature balance throughout summer humidity and winter hearth warmth.'
    }
  ];

  return (
    <div id="journal-page" className="w-full bg-[#F7F4EE] min-h-screen pb-20 pt-4 sm:pt-6 text-left">
      <div className="max-w-7xl mx-auto px-4 sm:px-8">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-xs text-[#6E6C65] mb-6">
          <button onClick={onBackToHome} className="flex items-center gap-1 hover:text-[#26382C]">
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Home</span>
          </button>
          <span>/</span>
          <span className="text-[#24241F] font-medium">The Design Journal</span>
        </div>

        {/* Hero Header */}
        <div className="mb-12 border-b border-[#E5E0D8] pb-8">
          <span className="text-[11px] font-semibold tracking-[0.22em] text-[#4E5B43] uppercase block mb-1">
            ESSAYS & OBSERVATIONS
          </span>
          <h1 className="font-serif-display text-4xl sm:text-5xl text-[#24241F] font-normal tracking-tight">
            The Vale & Oak Journal
          </h1>
          <p className="text-[#6E6C65] text-base mt-2 max-w-2xl font-normal">
            Reflections on domestic architecture, timeless joinery, tactile material sourcing, and the subtle pleasures of quiet home living.
          </p>
        </div>

        {/* Articles Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {articles.map((article) => (
            <article 
              key={article.id}
              className="bg-white rounded-2xl border border-[#E5E0D8] overflow-hidden shadow-xs hover:shadow-md transition-all duration-300 flex flex-col justify-between group"
            >
              <div>
                <div className="aspect-video w-full overflow-hidden bg-[#F7F4EE]">
                  <img
                    src={article.image}
                    alt={article.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                </div>
                <div className="p-6">
                  <div className="flex items-center justify-between text-[11px] text-[#A99A87] mb-2 uppercase tracking-wider font-semibold">
                    <span className="text-[#4E5B43]">{article.category}</span>
                    <span className="flex items-center gap-1 text-[#6E6C65]">
                      <Clock className="w-3 h-3" />
                      {article.readTime}
                    </span>
                  </div>
                  <h2 className="font-serif-display text-xl text-[#24241F] group-hover:text-[#26382C] transition-colors leading-snug mb-3">
                    {article.title}
                  </h2>
                  <p className="text-xs text-[#6E6C65] leading-relaxed font-normal">
                    {article.excerpt}
                  </p>
                </div>
              </div>

              <div className="px-6 pb-6 pt-2">
                <span className="text-xs font-semibold uppercase tracking-wider text-[#26382C] group-hover:text-[#4E5B43] inline-flex items-center gap-1.5 transition-colors">
                  <span>Read Article</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                </span>
              </div>
            </article>
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="mt-16 p-8 rounded-2xl bg-[#EEE9DF] border border-[#E5E0D8] flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            <h3 className="font-serif-display text-2xl text-[#24241F]">
              Explore our current furniture collection
            </h3>
            <p className="text-xs text-[#6E6C65] mt-0.5">
              Experience the craftsmanship discussed in our journal firsthand.
            </p>
          </div>
          <button
            onClick={onShopClick}
            className="px-6 py-3 bg-[#26382C] text-white rounded-lg text-xs font-semibold uppercase tracking-wider hover:bg-[#19271E] transition-colors whitespace-nowrap"
          >
            Shop Collection
          </button>
        </div>
      </div>
    </div>
  );
};
