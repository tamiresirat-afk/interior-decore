import React, { useState, useEffect, useRef } from 'react';
import { Home, PackageCheck, ThumbsUp, Star } from 'lucide-react';
import { STORE_STATS } from '../data/products';

export const StoreStatistics: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.25 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const icons = [Home, PackageCheck, ThumbsUp, Star];

  return (
    <section 
      ref={sectionRef}
      id="store-statistics-section" 
      className="w-full py-12 sm:py-16 bg-white border-y border-[#E5E0D8]"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 md:gap-4 divide-y sm:divide-y-0 md:divide-x divide-[#E5E0D8]">
          {STORE_STATS.map((stat, idx) => {
            const Icon = icons[idx];
            return (
              <div 
                key={idx} 
                className={`text-center flex flex-col items-center justify-center p-2 sm:p-4 ${
                  idx > 1 ? 'pt-6 sm:pt-0' : ''
                }`}
              >
                {/* Minimal line icon */}
                <div className="w-10 h-10 rounded-full bg-[#F7F4EE] border border-[#E5E0D8] flex items-center justify-center text-[#4E5B43] mb-3">
                  <Icon className="w-5 h-5 stroke-[1.75]" />
                </div>

                {/* Animated value */}
                <div className="font-serif-display text-3xl sm:text-4xl lg:text-5xl font-normal text-[#24241F] tracking-tight mb-1">
                  <AnimatedNumber 
                    target={stat.value} 
                    suffix={stat.suffix} 
                    trigger={isVisible} 
                  />
                </div>

                {/* Label */}
                <h4 className="text-xs sm:text-[13px] font-semibold tracking-wider text-[#24241F] uppercase mb-0.5">
                  {stat.label}
                </h4>

                {/* Sublabel */}
                <p className="text-[11px] sm:text-xs text-[#6E6C65] font-normal">
                  {stat.sublabel}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

// Restrained count-up helper that respects prefers-reduced-motion
const AnimatedNumber: React.FC<{ target: number; suffix: string; trigger: boolean }> = ({ 
  target, 
  suffix, 
  trigger 
}) => {
  const [current, setCurrent] = useState(0);

  useEffect(() => {
    if (!trigger) return;

    // Check if user prefers reduced motion
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (prefersReducedMotion) {
      setCurrent(target);
      return;
    }

    let start = 0;
    const duration = 1200; // 1.2s smooth count
    const steps = 40;
    const increment = target / steps;
    const stepTime = duration / steps;

    const timer = setInterval(() => {
      start += increment;
      if (start >= target) {
        setCurrent(target);
        clearInterval(timer);
      } else {
        setCurrent(target % 1 !== 0 ? Math.round(start * 10) / 10 : Math.round(start));
      }
    }, stepTime);

    return () => clearInterval(timer);
  }, [trigger, target]);

  return (
    <span>
      {target % 1 !== 0 ? current.toFixed(1) : current}
      {suffix}
    </span>
  );
};
